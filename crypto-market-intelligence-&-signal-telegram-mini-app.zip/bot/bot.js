/**
 * Standalone Production Telegram Bot for Crypto Market Intelligence
 * Can be run independently on any VPS/server with:
 * node bot/bot.js
 */

import dotenv from 'dotenv';
dotenv.config();

const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const API_URL = process.env.APP_URL || 'http://localhost:3000';

if (!BOT_TOKEN) {
  console.warn('[TelegramBot] Warning: TELEGRAM_BOT_TOKEN environment variable is not defined.');
  console.warn('[TelegramBot] Please configure TELEGRAM_BOT_TOKEN in .env to run live polling.');
}

const TELEGRAM_API = `https://api.telegram.org/bot${BOT_TOKEN}`;

async function sendTelegramMessage(chatId, text, replyMarkup) {
  if (!BOT_TOKEN) return;
  try {
    const res = await fetch(`${TELEGRAM_API}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        text,
        parse_mode: 'HTML',
        reply_markup: replyMarkup,
      }),
    });
    return await res.json();
  } catch (err) {
    console.error('[TelegramBot] Failed to send message:', err.message);
  }
}

async function handleUpdate(update) {
  if (!update.message || !update.message.text) return;

  const text = update.message.text.trim();
  const chatId = update.message.chat.id;

  try {
    // Forward command to the backend API
    const response = await fetch(`${API_URL}/api/telegram/command`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ command: text, chatId: String(chatId) }),
    });

    const data = await response.json();
    if (data && data.text) {
      await sendTelegramMessage(chatId, data.text, data.replyMarkup);
    }
  } catch (err) {
    console.error('[TelegramBot] Error dispatching command to backend:', err.message);
    await sendTelegramMessage(
      chatId,
      '⚠️ Unable to connect to Market Intelligence server. Please ensure backend is running.'
    );
  }
}

let offset = 0;
let isPolling = false;

async function startLongPolling() {
  if (!BOT_TOKEN) {
    console.log('[TelegramBot] Bot token missing. Polling idle.');
    return;
  }

  isPolling = true;
  console.log('[TelegramBot] Long polling started successfully...');

  while (isPolling) {
    try {
      const res = await fetch(`${TELEGRAM_API}/getUpdates?offset=${offset}&timeout=30`);
      const data = await res.json();

      if (data.ok && Array.isArray(data.result)) {
        for (const update of data.result) {
          offset = update.update_id + 1;
          await handleUpdate(update);
        }
      } else if (!data.ok) {
        console.error('[TelegramBot] Telegram API returned:', data.description);
        await new Promise((r) => setTimeout(r, 5000));
      }
    } catch (err) {
      console.error('[TelegramBot] Network poll error:', err.message);
      await new Promise((r) => setTimeout(r, 3000));
    }
  }
}

if (process.argv[1]?.endsWith('bot.js')) {
  startLongPolling();
}

export { startLongPolling };
