import {
  Coin,
  Candle,
  Signal,
  SignalDirection,
  SignalClassification,
  SignalRisk,
  TimeFrame,
} from '../types/crypto.ts';
import { computeAllIndicators } from './indicators.ts';
import { binanceService } from './binance.ts';
import { SECTOR_DEFINITIONS, calculateSectorData } from './sectors.ts';

const DISCLAIMER_TEXT =
  'Crypto markets are highly volatile. Signals are algorithmic market analysis, not guaranteed predictions or financial advice.';

export class SignalEngine {
  private activeSignals: Signal[] = [];
  private lastEvaluationTime: number = 0;

  public getActiveSignals(): Signal[] {
    // Filter out expired signals
    const now = Date.now();
    return this.activeSignals.filter((s) => s.expiresAt > now);
  }

  public getSignalBySymbol(symbol: string): Signal | undefined {
    return this.activeSignals.find((s) => s.symbol === symbol && s.expiresAt > Date.now());
  }

  /**
   * Evaluates all coins and generates bullish/bearish setups
   */
  public async evaluateAllCoins(): Promise<Signal[]> {
    const coins = binanceService.getAllCoins();
    if (coins.length === 0) return [];

    const btcCoin = coins.find((c) => c.symbol === 'BTCUSDT');
    const btcTrendBullish = (btcCoin?.change24h || 0) > 0.5;
    const btcTrendBearish = (btcCoin?.change24h || 0) < -1.5;

    // Temporary map to calculate sector performance
    const coinStatsMap = new Map<
      string,
      { momentum: number; volumeChange: number; direction: 'BULLISH' | 'BEARISH' | 'NEUTRAL'; score: number }
    >();

    const candidateSignals: Signal[] = [];

    // First pass: Compute indicators and candidate setups
    for (const coin of coins) {
      try {
        const candles = await binanceService.fetchKlines(coin.symbol, '1h', 50);
        const indicators = computeAllIndicators(candles);

        // Analyze setup for 12H and 24H horizons
        const setup12H = this.analyzeCoin(coin, indicators, candles, '12H', btcTrendBullish, btcTrendBearish);
        if (setup12H && setup12H.score >= 50) {
          candidateSignals.push(setup12H);
        }

        const setup24H = this.analyzeCoin(coin, indicators, candles, '24H', btcTrendBullish, btcTrendBearish);
        if (setup24H && setup24H.score >= 65) {
          candidateSignals.push(setup24H);
        }

        coinStatsMap.set(coin.symbol, {
          momentum: indicators.momentum,
          volumeChange: indicators.volumeChange,
          direction: setup12H?.direction || 'NEUTRAL',
          score: setup12H?.score || 50,
        });
      } catch (err) {
        console.error(`Error analyzing coin ${coin.symbol}:`, err);
      }
    }

    // Second pass: Factor in Sector Performance
    for (const signal of candidateSignals) {
      const sectorDef = SECTOR_DEFINITIONS.find((s) => s.coins.includes(signal.symbol));
      if (sectorDef) {
        const sectorData = calculateSectorData(sectorDef, coinStatsMap);
        if (signal.direction === 'BULLISH' && sectorData.status === 'Bullish') {
          signal.score = Math.min(100, signal.score + 5);
          if (!signal.reasons.some((r) => r.includes('Sector'))) {
            signal.reasons.push(`Sector trend supportive (${sectorData.name} bullish)`);
          }
        } else if (signal.direction === 'BEARISH' && sectorData.status === 'Bearish') {
          signal.score = Math.min(100, signal.score + 5);
          if (!signal.reasons.some((r) => r.includes('Sector'))) {
            signal.reasons.push(`Sector weakness detected (${sectorData.name} bearish)`);
          }
        }
        signal.classification = this.classifyScore(signal.score);
      }
    }

    // Sort by score descending
    candidateSignals.sort((a, b) => b.score - a.score);

    this.activeSignals = candidateSignals;
    this.lastEvaluationTime = Date.now();
    return this.activeSignals;
  }

  private classifyScore(score: number): SignalClassification {
    if (score >= 80) return 'Strong Setup';
    if (score >= 65) return 'Moderate Setup';
    if (score >= 50) return 'Watchlist';
    return 'No Signal';
  }

  private analyzeCoin(
    coin: Coin,
    ind: ReturnType<typeof computeAllIndicators>,
    candles: Candle[],
    timeframe: TimeFrame,
    btcBullish: boolean,
    btcBearish: boolean
  ): Signal | null {
    const currentPrice = coin.price;
    const now = Date.now();
    const durationHours = timeframe === '12H' ? 12 : 24;
    const expiresAt = now + durationHours * 3600 * 1000;

    let bullishPoints = 0;
    let bearishPoints = 0;
    const bullishReasons: string[] = [];
    const bearishReasons: string[] = [];

    // 1. Technical Moving Averages (EMA 20, 50, 200) - Max 25 pts
    if (ind.ema20 > ind.ema50 && ind.ema50 > ind.ema200) {
      bullishPoints += 25;
      bullishReasons.push('EMA bullish alignment (EMA20 > EMA50 > EMA200)');
    } else if (currentPrice > ind.ema20 && ind.ema20 > ind.ema50) {
      bullishPoints += 18;
      bullishReasons.push('Price consolidating above EMA20 and EMA50');
    } else if (ind.ema20 < ind.ema50 && ind.ema50 < ind.ema200) {
      bearishPoints += 25;
      bearishReasons.push('EMA bearish alignment (EMA20 < EMA50 < EMA200)');
    } else if (currentPrice < ind.ema20 && ind.ema20 < ind.ema50) {
      bearishPoints += 18;
      bearishReasons.push('Price suppressed below EMA20 and EMA50');
    }

    // 2. Momentum & RSI - Max 20 pts
    if (ind.rsi >= 50 && ind.rsi <= 68 && ind.momentum > 1.2) {
      bullishPoints += 20;
      bullishReasons.push(`Positive momentum detected (RSI ${ind.rsi.toFixed(0)}, momentum +${ind.momentum.toFixed(1)}%)`);
    } else if (ind.rsi > 35 && ind.rsi < 50 && ind.momentum > 0) {
      bullishPoints += 14;
      bullishReasons.push('RSI recovery from oversold zone with upward velocity');
    } else if (ind.rsi >= 75) {
      // Overbought - potential downside risk
      bearishPoints += 12;
      bearishReasons.push(`Overbought conditions detected (RSI ${ind.rsi.toFixed(0)}) with exhaustion risk`);
    } else if (ind.rsi <= 45 && ind.momentum < -1.5) {
      bearishPoints += 20;
      bearishReasons.push(`Negative momentum expanding (RSI ${ind.rsi.toFixed(0)}, momentum ${ind.momentum.toFixed(1)}%)`);
    }

    // 3. MACD - Max 20 pts
    if (ind.macd.histogram > 0 && ind.macd.macd > ind.macd.signal) {
      bullishPoints += 20;
      bullishReasons.push('MACD positive histogram expansion');
    } else if (ind.macd.histogram < 0 && ind.macd.macd < ind.macd.signal) {
      bearishPoints += 20;
      bearishReasons.push('MACD negative histogram divergence');
    }

    // 4. Volume Profile - Max 15 pts
    if (ind.volumeChange > 20) {
      if (coin.change24h > 0) {
        bullishPoints += 15;
        bullishReasons.push(`Volume increasing (+${ind.volumeChange.toFixed(0)}% above 20-period average)`);
      } else {
        bearishPoints += 15;
        bearishReasons.push(`Heavy selling volume observed (+${ind.volumeChange.toFixed(0)}% above average)`);
      }
    } else if (ind.volumeChange > 5) {
      if (coin.change24h > 0) {
        bullishPoints += 8;
        bullishReasons.push('Steady accumulation volume detected');
      } else {
        bearishPoints += 8;
        bearishReasons.push('Elevated sell volume pressure');
      }
    }

    // 5. Market Trend / BTC Alignment - Max 10 pts
    if (btcBullish) {
      bullishPoints += 10;
      bullishReasons.push('BTC market trend supportive');
    } else if (btcBearish) {
      bearishPoints += 10;
      bearishReasons.push('Broad market headwind (BTC weakness)');
    }

    // 6. Support & Resistance Proximity - Max 10 pts
    const distToSupport = ((currentPrice - ind.support) / currentPrice) * 100;
    const distToResistance = ((ind.resistance - currentPrice) / currentPrice) * 100;

    if (distToSupport > 0 && distToSupport < 3.5) {
      bullishPoints += 10;
      bullishReasons.push(`Rebounding from key support zone near $${ind.support.toFixed(2)}`);
    }
    if (distToResistance > 0 && distToResistance < 3.0) {
      bearishPoints += 10;
      bearishReasons.push(`Encountering key resistance barrier near $${ind.resistance.toFixed(2)}`);
    }

    // Decide direction & score
    let direction: SignalDirection = 'NEUTRAL';
    let rawScore = 0;
    let reasons: string[] = [];

    if (bullishPoints >= bearishPoints && bullishPoints >= 50) {
      direction = 'BULLISH';
      rawScore = bullishPoints;
      reasons = bullishReasons;
      reasons.unshift('Bullish setup detected: Upside momentum increasing');
    } else if (bearishPoints > bullishPoints && bearishPoints >= 50) {
      direction = 'BEARISH';
      rawScore = bearishPoints;
      reasons = bearishReasons;
      reasons.unshift('Bearish setup detected: Downside risk increasing');
    } else {
      return null;
    }

    const score = Math.min(100, Math.max(0, rawScore));
    const classification = this.classifyScore(score);

    // Calculate Risk Level (Low, Medium, High) based on ATR and Volatility
    let risk: SignalRisk = 'MEDIUM';
    const atrPct = (ind.atr / currentPrice) * 100;
    if (atrPct > 5.0 || ind.volatility > 4.0) {
      risk = 'HIGH';
    } else if (atrPct < 2.0 && ind.volatility < 2.0) {
      risk = 'LOW';
    }

    return {
      id: `sig_${coin.symbol}_${timeframe}_${now}`,
      coin: coin.name,
      symbol: coin.symbol,
      timestamp: now,
      expiresAt,
      timeframe,
      direction,
      score,
      classification,
      risk,
      reasons,
      indicators: ind,
      priceAtSignal: currentPrice,
      status: 'ACTIVE',
      disclaimer: DISCLAIMER_TEXT,
    };
  }

  public getLastEvaluationTime(): number {
    return this.lastEvaluationTime;
  }
}

export const signalEngine = new SignalEngine();
