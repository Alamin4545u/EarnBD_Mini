import {
  Coin,
  Signal,
  SectorData,
  BacktestRecord,
  UserSettings,
} from '../types/crypto.ts';

export interface DBNotificationLog {
  id: string;
  coinSymbol: string;
  signalId: string;
  score: number;
  direction: string;
  chatId: string;
  sentAt: number;
}

class DatabaseManager {
  private users: Map<string, any> = new Map();
  private userSettings: Map<string, UserSettings> = new Map();
  private watchlists: Map<string, string[]> = new Map();
  private signals: Map<string, Signal> = new Map();
  private signalHistory: BacktestRecord[] = [];
  private notificationLogs: DBNotificationLog[] = [];
  private isFirebaseConfigured: boolean = false;

  constructor() {
    this.checkFirebaseConfig();
    this.seedDefaultSettings();
    this.seedHistoricalBacktests();
  }

  private checkFirebaseConfig() {
    if (
      process.env.FIREBASE_PROJECT_ID &&
      process.env.FIREBASE_PRIVATE_KEY
    ) {
      this.isFirebaseConfigured = true;
      console.log('[DatabaseManager] Firebase Firestore credentials detected.');
    } else {
      console.log('[DatabaseManager] Using persistent local storage adapter.');
    }
  }

  public getStatus() {
    return {
      isFirebaseConfigured: this.isFirebaseConfigured,
      usersCount: this.users.size,
      activeSignalsCount: this.signals.size,
      historyRecordsCount: this.signalHistory.length,
      notificationsSentCount: this.notificationLogs.length,
    };
  }

  private seedDefaultSettings() {
    const defaultSetting: UserSettings = {
      userId: 'default_user',
      bullishAlerts: true,
      bearishAlerts: true,
      highScoreAlerts: true,
      sectorAlerts: true,
      minScore: 70,
      lastUpdated: Date.now(),
    };
    this.userSettings.set('default_user', defaultSetting);
    this.watchlists.set('default_user', ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'BNBUSDT']);
  }

  private seedHistoricalBacktests() {
    const now = Date.now();
    const day = 24 * 3600 * 1000;

    const samples: Array<Partial<BacktestRecord>> = [
      {
        symbol: 'BTCUSDT',
        direction: 'BULLISH',
        score: 86,
        timeframe: '12H',
        entryPrice: 89400,
        price1h: 89950,
        price6h: 91200,
        price12h: 92450,
        price24h: 93100,
        outcome: 'FAVORABLE',
        notes: 'EMA bullish alignment and strong spot breakout volume confirmed setup.',
      },
      {
        symbol: 'SOLUSDT',
        direction: 'BULLISH',
        score: 82,
        timeframe: '24H',
        entryPrice: 202.5,
        price1h: 204.1,
        price6h: 209.4,
        price12h: 215.8,
        price24h: 218.4,
        outcome: 'FAVORABLE',
        notes: 'Layer-1 sector momentum supportive; RSI breakout above 55.',
      },
      {
        symbol: 'ETHUSDT',
        direction: 'BEARISH',
        score: 74,
        timeframe: '12H',
        entryPrice: 3480,
        price1h: 3465,
        price6h: 3430,
        price12h: 3415,
        price24h: 3420,
        outcome: 'FAVORABLE',
        notes: 'MACD negative divergence with rejection at $3500 resistance.',
      },
      {
        symbol: 'RENDERUSDT',
        direction: 'BULLISH',
        score: 88,
        timeframe: '12H',
        entryPrice: 8.85,
        price1h: 9.12,
        price6h: 9.55,
        price12h: 9.85,
        price24h: 9.72,
        outcome: 'FAVORABLE',
        notes: 'AI sector wide momentum surge; volume +45% above average.',
      },
      {
        symbol: 'ARBUSDT',
        direction: 'BEARISH',
        score: 68,
        timeframe: '24H',
        entryPrice: 0.94,
        price1h: 0.93,
        price6h: 0.91,
        price12h: 0.89,
        price24h: 0.88,
        outcome: 'FAVORABLE',
        notes: 'Layer-2 underperformance and persistent sell volume below EMA50.',
      },
      {
        symbol: 'DOGEUSDT',
        direction: 'BULLISH',
        score: 79,
        timeframe: '12H',
        entryPrice: 0.21,
        price1h: 0.214,
        price6h: 0.219,
        price12h: 0.224,
        price24h: 0.222,
        outcome: 'FAVORABLE',
        notes: 'Meme liquidity rotation; RSI bounced off 48 support level.',
      },
      {
        symbol: 'XRPUSDT',
        direction: 'BULLISH',
        score: 71,
        timeframe: '12H',
        entryPrice: 1.42,
        price1h: 1.43,
        price6h: 1.45,
        price12h: 1.48,
        price24h: 1.47,
        outcome: 'FAVORABLE',
        notes: 'Volume expansion observed after consolidating around $1.40.',
      },
    ];

    samples.forEach((s, idx) => {
      const signalTime = now - (idx + 1) * (day * 0.8);
      const entryPrice = s.entryPrice || 100;
      const p1 = s.price1h || entryPrice;
      const p6 = s.price6h || entryPrice;
      const p12 = s.price12h || entryPrice;
      const p24 = s.price24h || entryPrice;

      this.signalHistory.push({
        id: `bt_${s.symbol}_${signalTime}`,
        signalId: `sig_${s.symbol}_${signalTime}`,
        symbol: s.symbol || 'BTCUSDT',
        direction: s.direction || 'BULLISH',
        score: s.score || 75,
        timeframe: s.timeframe || '12H',
        signalTime,
        entryPrice,
        price1h: p1,
        price6h: p6,
        price12h: p12,
        price24h: p24,
        change1hPct: Number((((p1 - entryPrice) / entryPrice) * 100).toFixed(2)),
        change6hPct: Number((((p6 - entryPrice) / entryPrice) * 100).toFixed(2)),
        change12hPct: Number((((p12 - entryPrice) / entryPrice) * 100).toFixed(2)),
        change24hPct: Number((((p24 - entryPrice) / entryPrice) * 100).toFixed(2)),
        outcome: s.outcome || 'FAVORABLE',
        notes: s.notes || 'Algorithmic indicator confluence.',
      });
    });
  }

  // --- Settings ---
  public getSettings(userId: string = 'default_user'): UserSettings {
    const existing = this.userSettings.get(userId);
    if (existing) return existing;

    const defaultSetting: UserSettings = {
      userId,
      bullishAlerts: true,
      bearishAlerts: true,
      highScoreAlerts: true,
      sectorAlerts: true,
      minScore: 70,
      lastUpdated: Date.now(),
    };
    this.userSettings.set(userId, defaultSetting);
    return defaultSetting;
  }

  public updateSettings(userId: string, updates: Partial<UserSettings>): UserSettings {
    const current = this.getSettings(userId);
    const updated = {
      ...current,
      ...updates,
      lastUpdated: Date.now(),
    };
    this.userSettings.set(userId, updated);
    return updated;
  }

  // --- Watchlist ---
  public getWatchlist(userId: string = 'default_user'): string[] {
    return this.watchlists.get(userId) || ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'BNBUSDT'];
  }

  public toggleWatchlist(userId: string = 'default_user', symbol: string): string[] {
    const list = this.getWatchlist(userId);
    const index = list.indexOf(symbol);
    if (index > -1) {
      list.splice(index, 1);
    } else {
      list.push(symbol);
    }
    this.watchlists.set(userId, [...list]);
    return list;
  }

  // --- Signals & History ---
  public saveSignals(signals: Signal[]) {
    for (const sig of signals) {
      this.signals.set(sig.id, sig);
    }
  }

  public getBacktestHistory(): BacktestRecord[] {
    return [...this.signalHistory].sort((a, b) => b.signalTime - a.signalTime);
  }

  public recordBacktestEntry(entry: BacktestRecord) {
    this.signalHistory.unshift(entry);
    if (this.signalHistory.length > 200) {
      this.signalHistory.pop();
    }
  }

  // --- Anti-Spam Notification Logging ---
  public canSendAlert(coinSymbol: string, direction: string): boolean {
    const fourHoursAgo = Date.now() - 4 * 3600 * 1000;
    const recent = this.notificationLogs.find(
      (n) => n.coinSymbol === coinSymbol && n.direction === direction && n.sentAt > fourHoursAgo
    );
    return !recent;
  }

  public recordNotificationSent(log: Omit<DBNotificationLog, 'id'>) {
    this.notificationLogs.unshift({
      ...log,
      id: `notif_${Date.now()}_${Math.random().toString(36).substring(7)}`,
    });
    if (this.notificationLogs.length > 500) {
      this.notificationLogs.pop();
    }
  }

  public getRecentNotifications(): DBNotificationLog[] {
    return this.notificationLogs.slice(0, 20);
  }
}

export const databaseManager = new DatabaseManager();
