import { Candle, IndicatorValues } from '../types/crypto.ts';

/**
 * Calculates Simple Moving Average (SMA)
 */
export function calculateSMA(data: number[], period: number): number[] {
  const sma: number[] = [];
  if (data.length < period) return sma;

  let sum = 0;
  for (let i = 0; i < period; i++) {
    sum += data[i];
  }
  sma.push(sum / period);

  for (let i = period; i < data.length; i++) {
    sum += data[i] - data[i - period];
    sma.push(sum / period);
  }

  return sma;
}

/**
 * Calculates Exponential Moving Average (EMA)
 */
export function calculateEMA(data: number[], period: number): number[] {
  if (data.length < period) return [];
  const k = 2 / (period + 1);
  const ema: number[] = [];

  // Initialize with SMA
  let sum = 0;
  for (let i = 0; i < period; i++) {
    sum += data[i];
  }
  let prevEma = sum / period;
  ema.push(prevEma);

  for (let i = period; i < data.length; i++) {
    prevEma = data[i] * k + prevEma * (1 - k);
    ema.push(prevEma);
  }

  return ema;
}

/**
 * Calculates Relative Strength Index (RSI) with Wilder's smoothing
 */
export function calculateRSI(closes: number[], period: number = 14): number[] {
  if (closes.length <= period) return [];

  const gains: number[] = [];
  const losses: number[] = [];

  for (let i = 1; i < closes.length; i++) {
    const diff = closes[i] - closes[i - 1];
    gains.push(diff > 0 ? diff : 0);
    losses.push(diff < 0 ? Math.abs(diff) : 0);
  }

  if (gains.length < period) return [];

  let avgGain = gains.slice(0, period).reduce((a, b) => a + b, 0) / period;
  let avgLoss = losses.slice(0, period).reduce((a, b) => a + b, 0) / period;

  const rsiValues: number[] = [];
  const rs = avgLoss === 0 ? 100 : avgGain / avgLoss;
  rsiValues.push(avgLoss === 0 ? 100 : 100 - 100 / (1 + rs));

  for (let i = period; i < gains.length; i++) {
    avgGain = (avgGain * (period - 1) + gains[i]) / period;
    avgLoss = (avgLoss * (period - 1) + losses[i]) / period;

    const currentRs = avgLoss === 0 ? 100 : avgGain / avgLoss;
    const rsi = avgLoss === 0 ? 100 : 100 - 100 / (1 + currentRs);
    rsiValues.push(rsi);
  }

  return rsiValues;
}

/**
 * Calculates Moving Average Convergence Divergence (MACD)
 */
export function calculateMACD(
  closes: number[],
  fastPeriod: number = 12,
  slowPeriod: number = 26,
  signalPeriod: number = 9
): { macd: number; signal: number; histogram: number } {
  if (closes.length < slowPeriod + signalPeriod) {
    return { macd: 0, signal: 0, histogram: 0 };
  }

  const fastEMA = calculateEMA(closes, fastPeriod);
  const slowEMA = calculateEMA(closes, slowPeriod);

  // Align EMAs
  const offset = slowPeriod - fastPeriod;
  const macdLine: number[] = [];
  for (let i = 0; i < slowEMA.length; i++) {
    macdLine.push(fastEMA[i + offset] - slowEMA[i]);
  }

  const signalLine = calculateEMA(macdLine, signalPeriod);
  if (signalLine.length === 0) {
    return { macd: 0, signal: 0, histogram: 0 };
  }

  const latestMacd = macdLine[macdLine.length - 1];
  const latestSignal = signalLine[signalLine.length - 1];
  const histogram = latestMacd - latestSignal;

  return {
    macd: Number(latestMacd.toFixed(4)),
    signal: Number(latestSignal.toFixed(4)),
    histogram: Number(histogram.toFixed(4)),
  };
}

/**
 * Calculates Average True Range (ATR)
 */
export function calculateATR(candles: Candle[], period: number = 14): number {
  if (candles.length <= period) return 0;

  const trueRanges: number[] = [];
  for (let i = 1; i < candles.length; i++) {
    const high = candles[i].high;
    const low = candles[i].low;
    const prevClose = candles[i - 1].close;

    const tr = Math.max(
      high - low,
      Math.abs(high - prevClose),
      Math.abs(low - prevClose)
    );
    trueRanges.push(tr);
  }

  // Wilder's ATR
  let atr = trueRanges.slice(0, period).reduce((a, b) => a + b, 0) / period;
  for (let i = period; i < trueRanges.length; i++) {
    atr = (atr * (period - 1) + trueRanges[i]) / period;
  }

  return Number(atr.toFixed(4));
}

/**
 * Support and Resistance calculation using recent swing pivots
 */
export function calculateSupportResistance(candles: Candle[]): { support: number; resistance: number } {
  if (candles.length < 10) {
    const last = candles[candles.length - 1]?.close || 100;
    return { support: last * 0.95, resistance: last * 1.05 };
  }

  const window = candles.slice(-30);
  const lows = window.map((c) => c.low);
  const highs = window.map((c) => c.high);
  const currentPrice = window[window.length - 1].close;

  // Find lowest low below current price
  const candidateSupports = lows.filter((l) => l < currentPrice);
  const support = candidateSupports.length > 0 
    ? Math.max(...candidateSupports.slice(-15)) 
    : Math.min(...lows);

  // Find highest high above current price
  const candidateResistances = highs.filter((h) => h > currentPrice);
  const resistance = candidateResistances.length > 0 
    ? Math.min(...candidateResistances.slice(-15)) 
    : Math.max(...highs);

  return {
    support: Number(support.toFixed(4)),
    resistance: Number(resistance.toFixed(4)),
  };
}

/**
 * Calculates all combined technical indicators for a given candle series
 */
export function computeAllIndicators(candles: Candle[]): IndicatorValues {
  if (!candles || candles.length === 0) {
    return {
      rsi: 50,
      macd: { macd: 0, signal: 0, histogram: 0 },
      ema20: 0,
      ema50: 0,
      ema200: 0,
      sma20: 0,
      sma50: 0,
      atr: 0,
      volumeChange: 0,
      momentum: 0,
      volatility: 0,
      support: 0,
      resistance: 0,
    };
  }

  const closes = candles.map((c) => c.close);
  const volumes = candles.map((c) => c.volume);
  const currentPrice = closes[closes.length - 1];

  // Moving averages
  const ema20Arr = calculateEMA(closes, 20);
  const ema50Arr = calculateEMA(closes, 50);
  const ema200Arr = calculateEMA(closes, 200);
  const sma20Arr = calculateSMA(closes, 20);
  const sma50Arr = calculateSMA(closes, 50);

  const ema20 = ema20Arr.length > 0 ? ema20Arr[ema20Arr.length - 1] : currentPrice;
  const ema50 = ema50Arr.length > 0 ? ema50Arr[ema50Arr.length - 1] : currentPrice;
  const ema200 = ema200Arr.length > 0 ? ema200Arr[ema200Arr.length - 1] : currentPrice * 0.98;
  const sma20 = sma20Arr.length > 0 ? sma20Arr[sma20Arr.length - 1] : currentPrice;
  const sma50 = sma50Arr.length > 0 ? sma50Arr[sma50Arr.length - 1] : currentPrice;

  // RSI
  const rsiArr = calculateRSI(closes, 14);
  const rsi = rsiArr.length > 0 ? rsiArr[rsiArr.length - 1] : 50;

  // MACD
  const macd = calculateMACD(closes);

  // ATR
  const atr = calculateATR(candles, 14);

  // Volume Change vs 20-period average
  const recentVols = volumes.slice(-20);
  const avgVol = recentVols.reduce((a, b) => a + b, 0) / (recentVols.length || 1);
  const currentVol = volumes[volumes.length - 1] || avgVol;
  const volumeChange = avgVol > 0 ? ((currentVol - avgVol) / avgVol) * 100 : 0;

  // Price Momentum (over last 10 periods)
  const lookbackPrice = closes[Math.max(0, closes.length - 10)];
  const momentum = lookbackPrice > 0 ? ((currentPrice - lookbackPrice) / lookbackPrice) * 100 : 0;

  // Volatility: standard deviation / mean of last 20 closes
  const sliceCloses = closes.slice(-20);
  const mean = sliceCloses.reduce((a, b) => a + b, 0) / (sliceCloses.length || 1);
  const variance = sliceCloses.reduce((acc, val) => acc + Math.pow(val - mean, 2), 0) / (sliceCloses.length || 1);
  const volatility = mean > 0 ? (Math.sqrt(variance) / mean) * 100 : 0;

  // Support & Resistance
  const { support, resistance } = calculateSupportResistance(candles);

  return {
    rsi: Number(rsi.toFixed(2)),
    macd,
    ema20: Number(ema20.toFixed(4)),
    ema50: Number(ema50.toFixed(4)),
    ema200: Number(ema200.toFixed(4)),
    sma20: Number(sma20.toFixed(4)),
    sma50: Number(sma50.toFixed(4)),
    atr: Number(atr.toFixed(4)),
    volumeChange: Number(volumeChange.toFixed(2)),
    momentum: Number(momentum.toFixed(2)),
    volatility: Number(volatility.toFixed(2)),
    support: Number(support.toFixed(4)),
    resistance: Number(resistance.toFixed(4)),
  };
}
