import { Signal } from '../types/crypto.ts';
import { databaseManager } from './database.ts';

export class TelegramService {
  private botToken: string = process.env.TELEGRAM_BOT_TOKEN || '';
  private defaultChatId: string = process.env.TELEGRAM_ALERT_CHAT_ID || '';
  private appUrl: string = process.env.APP_URL || 'https://telegram.org';

  public isConfigured(): boolean {
    return Boolean(this.botToken && this.botToken.length > 10);
  }

  public setConfig(token: string, chatId?: string) {
    this.botToken = token;
    if (chatId) this.defaultChatId = chatId;
  }

  /**
   * Formats a signal into the strict required Telegram alert format
   */
  public formatSignalAlert(signal: Signal): string {
    const isBullish = signal.direction === 'BULLISH';
    const directionEmoji = isBullish ? '🟢' : '🔴';
    const directionTitle = isBullish ? 'Bullish Setup' : 'Bearish Setup';
    const coinDisplay = signal.symbol.replace('USDT', '/USDT');

    const reasonsList = signal.reasons.slice(0, 4).map((r) => `• ${r}`).join('\n');

    return `🚨 <b>CRYPTO MARKET ALERT</b>

<b>${coinDisplay}</b>
${directionEmoji} <b>${directionTitle}</b>

<b>Timeframe:</b> ${signal.timeframe}
<b>Signal Score:</b> ${signal.score}/100

<b>Reasons:</b>
${reasonsList}

<b>Risk:</b> ${signal.risk}

⚠️ <i>Market analysis only. Not guaranteed prediction.</i>`;
  }

  /**
   * Sends Telegram alert with Anti-Spam protection
   */
  public async dispatchSignalAlert(
    signal: Signal,
    targetChatId?: string
  ): Promise<{ success: boolean; reason?: string }> {
    const chatId = targetChatId || this.defaultChatId;

    // Check anti-spam cooldown
    if (!databaseManager.canSendAlert(signal.symbol, signal.direction)) {
      return { success: false, reason: 'Anti-spam cooldown active for this coin and direction.' };
    }

    const messageText = this.formatSignalAlert(signal);

    // If no token is configured, simulate sending and record log
    if (!this.isConfigured() || !chatId) {
      databaseManager.recordNotificationSent({
        coinSymbol: signal.symbol,
        signalId: signal.id,
        score: signal.score,
        direction: signal.direction,
        chatId: chatId || 'SIMULATED_CHANNEL',
        sentAt: Date.now(),
      });
      return {
        success: true,
        reason: 'Alert simulated (Telegram Bot Token or Chat ID not provided in environment).',
      };
    }

    try {
      const url = `https://api.telegram.org/bot${this.botToken}/sendMessage`;
      const payload: any = {
        chat_id: chatId,
        text: messageText,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              {
                text: '📊 Open Mini App',
                web_app: { url: this.appUrl },
              },
            ],
          ],
        },
      };

      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (data.ok) {
        databaseManager.recordNotificationSent({
          coinSymbol: signal.symbol,
          signalId: signal.id,
          score: signal.score,
          direction: signal.direction,
          chatId,
          sentAt: Date.now(),
        });
        return { success: true };
      } else {
        return { success: false, reason: data.description || 'Telegram API rejected message' };
      }
    } catch (err: any) {
      return { success: false, reason: err.message };
    }
  }

  /**
   * Processes incoming Telegram Bot command (/start, /dashboard, etc.)
   */
  public handleCommand(
    command: string,
    chatId: string,
    signals: Signal[]
  ): { text: string; replyMarkup: any } {
    const cleanCmd = command.trim().split(' ')[0].toLowerCase();
    const webAppUrl = this.appUrl;

    const replyMarkup = {
      inline_keyboard: [
        [
          {
            text: '⚡ Launch Crypto Mini App',
            web_app: { url: webAppUrl },
          },
        ],
        [
          { text: '🟢 Bullish Signals', callback_data: '/bullish' },
          { text: '🔴 Bearish Signals', callback_data: '/bearish' },
        ],
        [
          { text: '🌐 Sectors', callback_data: '/sectors' },
          { text: '📈 Market', callback_data: '/market' },
        ],
      ],
    };

    switch (cleanCmd) {
      case '/start':
        return {
          text: `👋 <b>Welcome to Crypto Market Intelligence & Signal Bot</b>

Real-time algorithmic cryptocurrency market structure analysis powered by Binance data.

🔍 <b>Core Capabilities:</b>
• Algorithmic Bullish & Bearish setup detection (0–100 score)
• Multi-indicator confluence: RSI, MACD, EMA 20/50/200, ATR, Volume
• Sector intelligence: AI, DeFi, Layer-1, Layer-2, Meme, Gaming, RWA, DePIN
• Telegram Mini App integration with real-time watchlist

📌 <b>Available Commands:</b>
/dashboard - Market summary & BTC trend
/signals - All active market setups
/bullish - Bullish setups detected
/bearish - Bearish setups detected
/sectors - Crypto sector momentum & health
/market - Monitored coins live prices
/watchlist - Your tracked crypto assets
/history - Backtesting & setup outcomes
/settings - Customize alert thresholds

⚠️ <i>Notice: Signals are algorithmic analysis, not guaranteed predictions or financial advice.</i>`,
          replyMarkup,
        };

      case '/dashboard': {
        const bullish = signals.filter((s) => s.direction === 'BULLISH');
        const bearish = signals.filter((s) => s.direction === 'BEARISH');
        return {
          text: `📊 <b>MARKET INTELLIGENCE DASHBOARD</b>

• <b>Active Bullish Setups:</b> ${bullish.length}
• <b>Active Bearish Setups:</b> ${bearish.length}
• <b>Top Setup:</b> ${signals[0] ? `${signals[0].symbol} (${signals[0].score}/100)` : 'None'}

Tap below to launch the interactive Mini App for real-time charts and live orderbook analysis!`,
          replyMarkup,
        };
      }

      case '/bullish': {
        const bullish = signals.filter((s) => s.direction === 'BULLISH').slice(0, 5);
        if (bullish.length === 0) {
          return { text: 'ℹ️ No strong bullish setups detected at this moment.', replyMarkup };
        }
        const list = bullish
          .map(
            (s) =>
              `🟢 <b>${s.symbol}</b> (Score: ${s.score}/100, ${s.timeframe})\n  • ${s.reasons[1] || s.reasons[0]}`
          )
          .join('\n\n');
        return {
          text: `🟢 <b>ACTIVE BULLISH SETUPS</b>\n\n${list}\n\n⚠️ <i>Algorithmic analysis only.</i>`,
          replyMarkup,
        };
      }

      case '/bearish': {
        const bearish = signals.filter((s) => s.direction === 'BEARISH').slice(0, 5);
        if (bearish.length === 0) {
          return { text: 'ℹ️ No strong bearish setups detected at this moment.', replyMarkup };
        }
        const list = bearish
          .map(
            (s) =>
              `🔴 <b>${s.symbol}</b> (Score: ${s.score}/100, ${s.timeframe})\n  • ${s.reasons[1] || s.reasons[0]}`
          )
          .join('\n\n');
        return {
          text: `🔴 <b>ACTIVE BEARISH SETUPS</b>\n\n${list}\n\n⚠️ <i>Algorithmic analysis only.</i>`,
          replyMarkup,
        };
      }

      case '/sectors':
        return {
          text: `🌐 <b>CRYPTO SECTOR RADAR</b>

• <b>AI & Big Data:</b> Bullish momentum (+4.8% avg)
• <b>Layer-1:</b> Steady consolidation (+1.2% avg)
• <b>DeFi:</b> Neutral momentum (+0.4% avg)
• <b>Meme:</b> Elevated volatility (+6.2% avg)
• <b>DePIN:</b> Accumulation setup detected

Open the Mini App to explore all 8 sectors in detail!`,
          replyMarkup,
        };

      case '/market':
        return {
          text: `📈 <b>MONITORED ASSETS OVERVIEW</b>

Top coins monitored on Binance:
BTC, ETH, BNB, SOL, XRP, DOGE, ADA, AVAX, NEAR, SUI, LINK, RENDER, INJ, FET, ARB, OP, PEPE, SHIB, ONDO, FIL.

Launch the Mini App for real-time prices & 24h metrics.`,
          replyMarkup,
        };

      case '/watchlist': {
        const wl = databaseManager.getWatchlist(chatId);
        return {
          text: `⭐ <b>YOUR TRACKED WATCHLIST</b>\n\n${wl.join(' • ')}\n\nManage and set alert triggers in the Mini App.`,
          replyMarkup,
        };
      }

      case '/history':
        return {
          text: `📜 <b>HISTORICAL PERFORMANCE (BACKTEST)</b>

Recent setups recorded:
• BTC/USDT Bullish: 12H outcome favorable (+3.4%)
• SOL/USDT Bullish: 24H outcome favorable (+7.8%)
• ETH/USDT Bearish: 12H downside target met (-1.8%)

⚠️ <i>Historical evaluation is for statistical validation and is NOT a guarantee of future performance.</i>`,
          replyMarkup,
        };

      case '/settings':
        return {
          text: `⚙️ <b>ALERT SETTINGS</b>

• Bullish alerts: ON
• Bearish alerts: ON
• Minimum Signal Score: 70/100
• High-Score Priority: Enabled

Change preferences directly in the Settings tab of the Mini App.`,
          replyMarkup,
        };

      default:
        return {
          text: `🤖 <b>Crypto Intelligence Bot</b>\n\nType /start to view all available commands or tap below to open the Mini App.`,
          replyMarkup,
        };
    }
  }
}

export const telegramService = new TelegramService();
