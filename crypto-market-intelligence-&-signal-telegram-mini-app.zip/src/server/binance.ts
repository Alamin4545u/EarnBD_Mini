import { Candle, Coin } from '../types/crypto.ts';
import { getSectorForCoin } from './sectors.ts';

export const MONITORED_SYMBOLS = [
  'BTCUSDT',
  'ETHUSDT',
  'BNBUSDT',
  'SOLUSDT',
  'XRPUSDT',
  'DOGEUSDT',
  'ADAUSDT',
  'AVAXUSDT',
  'NEARUSDT',
  'SUIUSDT',
  'LINKUSDT',
  'RENDERUSDT',
  'INJUSDT',
  'FETUSDT',
  'ARBUSDT',
  'OPUSDT',
  'PEPEUSDT',
  'SHIBUSDT',
  'ONDOUSDT',
  'FILUSDT',
];

interface CachedCandles {
  [key: string]: {
    data: Candle[];
    lastFetched: number;
  };
}

class BinanceService {
  private baseUrl = 'https://api.binance.com/api/v3';
  private cachedCoins: Map<string, Coin> = new Map();
  private cachedCandles: CachedCandles = {};
  private lastTickerUpdate = 0;
  private isConnected = false;
  private rateLimitWeight = 0;
  private errorLogs: Array<{ timestamp: number; service: string; message: string }> = [];

  constructor() {
    this.seedInitialData();
  }

  private logError(service: string, message: string) {
    console.error(`[BinanceService] [${service}]:`, message);
    this.errorLogs.unshift({
      timestamp: Date.now(),
      service,
      message,
    });
    if (this.errorLogs.length > 50) {
      this.errorLogs.pop();
    }
  }

  public getStatus() {
    return {
      isConnected: this.isConnected,
      lastTickerUpdate: this.lastTickerUpdate,
      coinsCount: this.cachedCoins.size,
      rateLimitWeight: this.rateLimitWeight,
      errorLogs: this.errorLogs.slice(0, 10),
    };
  }

  /**
   * Seed realistic initial baseline prices in case Binance public network is temporarily unreachable
   */
  private seedInitialData() {
    const baselines: Record<string, { price: number; change24h: number; volume: number }> = {
      BTCUSDT: { price: 92450.0, change24h: 3.42, volume: 48200 },
      ETHUSDT: { price: 3420.5, change24h: 2.85, volume: 385000 },
      BNBUSDT: { price: 685.2, change24h: 1.15, volume: 195000 },
      SOLUSDT: { price: 218.4, change24h: 5.62, volume: 1850000 },
      XRPUSDT: { price: 1.48, change24h: 4.12, volume: 14500000 },
      DOGEUSDT: { price: 0.224, change24h: 6.84, volume: 98000000 },
      ADAUSDT: { price: 0.782, change24h: 1.95, volume: 34000000 },
      AVAXUSDT: { price: 36.8, change24h: 4.25, volume: 1200000 },
      NEARUSDT: { price: 6.45, change24h: 8.12, volume: 8500000 },
      SUIUSDT: { price: 3.65, change24h: 7.45, volume: 11000000 },
      LINKUSDT: { price: 18.9, change24h: 3.15, volume: 2100000 },
      RENDERUSDT: { price: 9.85, change24h: 9.2, volume: 4200000 },
      INJUSDT: { price: 28.4, change24h: 4.8, volume: 950000 },
      FETUSDT: { price: 1.85, change24h: 11.4, volume: 18000000 },
      ARBUSDT: { price: 0.88, change24h: -1.2, volume: 14000000 },
      OPUSDT: { price: 1.95, change24h: 0.85, volume: 8200000 },
      PEPEUSDT: { price: 0.0000185, change24h: 12.8, volume: 420000000000 },
      SHIBUSDT: { price: 0.0000245, change24h: 3.9, volume: 85000000000 },
      ONDOUSDT: { price: 1.12, change24h: 5.4, volume: 5400000 },
      FILUSDT: { price: 5.85, change24h: 2.1, volume: 3200000 },
    };

    for (const [symbol, info] of Object.entries(baselines)) {
      const baseAsset = symbol.replace('USDT', '');
      this.cachedCoins.set(symbol, {
        symbol,
        name: baseAsset,
        baseAsset,
        price: info.price,
        change24h: info.change24h,
        high24h: Number((info.price * (1 + Math.abs(info.change24h) / 100 + 0.02)).toFixed(4)),
        low24h: Number((info.price * (1 - Math.abs(info.change24h) / 100 - 0.02)).toFixed(4)),
        volume24h: info.volume,
        quoteVolume24h: info.volume * info.price,
        sector: getSectorForCoin(symbol),
        lastUpdated: Date.now(),
      });
    }
  }

  /**
   * Fetch 24hr ticker data from Binance official API
   */
  public async fetchTickers(): Promise<Map<string, Coin>> {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 8000);

      const res = await fetch(`${this.baseUrl}/ticker/24hr`, {
        signal: controller.signal,
        headers: { 'User-Agent': 'CryptoSignalIntelligence/1.0' },
      });
      clearTimeout(timeoutId);

      if (!res.ok) {
        throw new Error(`Binance HTTP error ${res.status}: ${res.statusText}`);
      }

      const rawData = await res.json();
      if (Array.isArray(rawData)) {
        const symbolSet = new Set(MONITORED_SYMBOLS);
        for (const item of rawData) {
          if (symbolSet.has(item.symbol)) {
            const price = parseFloat(item.lastPrice);
            const change24h = parseFloat(item.priceChangePercent);
            const high24h = parseFloat(item.highPrice);
            const low24h = parseFloat(item.lowPrice);
            const volume24h = parseFloat(item.volume);
            const quoteVolume24h = parseFloat(item.quoteVolume);
            const baseAsset = item.symbol.replace('USDT', '');

            this.cachedCoins.set(item.symbol, {
              symbol: item.symbol,
              name: baseAsset,
              baseAsset,
              price,
              change24h: Number(change24h.toFixed(2)),
              high24h,
              low24h,
              volume24h,
              quoteVolume24h,
              sector: getSectorForCoin(item.symbol),
              lastUpdated: Date.now(),
            });
          }
        }
        this.isConnected = true;
        this.lastTickerUpdate = Date.now();
      }
    } catch (err: any) {
      this.logError('fetchTickers', err.message || 'Failed to fetch Binance tickers');
      // If we already have cache, keep isConnected true if cache is fresh
      if (this.cachedCoins.size > 0 && Date.now() - this.lastTickerUpdate < 120000) {
        this.isConnected = true;
      } else {
        this.isConnected = false;
      }
    }

    return this.cachedCoins;
  }

  /**
   * Fetch OHLCV candles from Binance
   * interval: '15m' | '1h' | '4h'
   */
  public async fetchKlines(
    symbol: string,
    interval: '15m' | '1h' | '4h' = '1h',
    limit: number = 100
  ): Promise<Candle[]> {
    const cacheKey = `${symbol}_${interval}_${limit}`;
    const cached = this.cachedCandles[cacheKey];

    // Return cached candles if less than 60 seconds old
    if (cached && Date.now() - cached.lastFetched < 60000) {
      return cached.data;
    }

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 6000);

      const url = `${this.baseUrl}/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`;
      const res = await fetch(url, { signal: controller.signal });
      clearTimeout(timeoutId);

      if (!res.ok) {
        throw new Error(`Binance klines error ${res.status}: ${res.statusText}`);
      }

      const raw = await res.json();
      if (Array.isArray(raw) && raw.length > 0) {
        const candles: Candle[] = raw.map((c: any) => ({
          timestamp: c[0],
          open: parseFloat(c[1]),
          high: parseFloat(c[2]),
          low: parseFloat(c[3]),
          close: parseFloat(c[4]),
          volume: parseFloat(c[5]),
        }));

        this.cachedCandles[cacheKey] = {
          data: candles,
          lastFetched: Date.now(),
        };

        return candles;
      }
    } catch (err: any) {
      this.logError(`fetchKlines(${symbol})`, err.message);
    }

    // Fallback: generate realistic synthetic series based on current coin price and 24h change
    if (cached && cached.data.length > 0) {
      return cached.data;
    }

    return this.generateSyntheticCandles(symbol, interval, limit);
  }

  /**
   * Generates realistic synthetic candles if live historical Binance endpoint is rate-limited
   */
  private generateSyntheticCandles(
    symbol: string,
    interval: string,
    limit: number
  ): Candle[] {
    const coin = this.cachedCoins.get(symbol);
    const basePrice = coin?.price || 100;
    const changePct = coin?.change24h || 2;
    const isBullish = changePct > 0;

    const candles: Candle[] = [];
    const intervalMs = interval === '15m' ? 15 * 60 * 1000 : interval === '4h' ? 4 * 3600 * 1000 : 3600 * 1000;
    const now = Date.now();

    let currentPrice = basePrice * (1 - (changePct / 100) * 0.7);

    for (let i = limit; i >= 0; i--) {
      const timestamp = now - i * intervalMs;
      // Drift towards final price
      const stepDrift = ((basePrice - currentPrice) / (i + 1)) * (isBullish ? 1.05 : 0.95);
      const volatility = currentPrice * 0.008;
      const randomNoise = (Math.sin(i * 0.5) + (Math.random() - 0.48)) * volatility;

      const open = currentPrice;
      const close = Math.max(0.000001, open + stepDrift + randomNoise);
      const high = Math.max(open, close) + Math.random() * volatility * 0.8;
      const low = Math.min(open, close) - Math.random() * volatility * 0.8;
      const volume = (coin?.volume24h || 100000) / limit * (0.7 + Math.random() * 0.6);

      candles.push({
        timestamp,
        open: Number(open.toFixed(4)),
        high: Number(high.toFixed(4)),
        low: Number(low.toFixed(4)),
        close: Number(close.toFixed(4)),
        volume: Number(volume.toFixed(2)),
      });

      currentPrice = close;
    }

    return candles;
  }

  public getAllCoins(): Coin[] {
    return Array.from(this.cachedCoins.values());
  }

  public getCoin(symbol: string): Coin | undefined {
    return this.cachedCoins.get(symbol);
  }
}

export const binanceService = new BinanceService();
