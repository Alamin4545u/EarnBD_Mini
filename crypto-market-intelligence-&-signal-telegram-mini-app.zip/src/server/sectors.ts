import { SectorData } from '../types/crypto.ts';

export interface SectorDefinition {
  id: string;
  name: string;
  coins: string[];
  description: string;
}

export const SECTOR_DEFINITIONS: SectorDefinition[] = [
  {
    id: 'ai',
    name: 'AI & Big Data',
    coins: ['FETUSDT', 'RENDERUSDT', 'NEARUSDT', 'INJUSDT'],
    description: 'Decentralized Artificial Intelligence, GPU computation, and machine learning networks',
  },
  {
    id: 'layer1',
    name: 'Layer-1',
    coins: ['BTCUSDT', 'ETHUSDT', 'BNBUSDT', 'SOLUSDT', 'ADAUSDT', 'AVAXUSDT', 'SUIUSDT'],
    description: 'Base foundational blockchain networks powering decentralized ecosystems',
  },
  {
    id: 'layer2',
    name: 'Layer-2',
    coins: ['ARBUSDT', 'OPUSDT', 'MATICUSDT'],
    description: 'Ethereum scaling solutions and rollup execution environments',
  },
  {
    id: 'defi',
    name: 'DeFi',
    coins: ['UNIUSDT', 'AAVEUSDT', 'LINKUSDT', 'INJUSDT'],
    description: 'Decentralized automated financial infrastructure and oracle networks',
  },
  {
    id: 'meme',
    name: 'Meme',
    coins: ['DOGEUSDT', 'SHIBUSDT', 'PEPEUSDT'],
    description: 'Community-driven viral and speculative liquidity tokens',
  },
  {
    id: 'gaming',
    name: 'Gaming & Metaverse',
    coins: ['GALAUSDT', 'IMXUSDT', 'SANDUSDT'],
    description: 'Web3 gaming platforms, NFT economies, and digital worlds',
  },
  {
    id: 'rwa',
    name: 'RWA (Real World Assets)',
    coins: ['ONDOUSDT', 'LINKUSDT', 'AVAXUSDT'],
    description: 'Tokenized treasuries, private credit, and institutional assets on-chain',
  },
  {
    id: 'depin',
    name: 'DePIN',
    coins: ['RENDERUSDT', 'FILUSDT', 'ARUSDT'],
    description: 'Decentralized physical infrastructure networks, storage, and distributed hardware',
  },
];

export function getSectorForCoin(symbol: string): string {
  for (const sector of SECTOR_DEFINITIONS) {
    if (sector.coins.includes(symbol)) {
      return sector.name;
    }
  }
  return 'Layer-1';
}

export function calculateSectorData(
  sector: SectorDefinition,
  coinStatsMap: Map<string, { momentum: number; volumeChange: number; direction: 'BULLISH' | 'BEARISH' | 'NEUTRAL'; score: number }>
): SectorData {
  let totalMomentum = 0;
  let totalVolChange = 0;
  let bullishCount = 0;
  let bearishCount = 0;
  let totalScore = 0;
  let countedCoins = 0;

  for (const coinSymbol of sector.coins) {
    const stats = coinStatsMap.get(coinSymbol);
    if (stats) {
      totalMomentum += stats.momentum;
      totalVolChange += stats.volumeChange;
      totalScore += stats.score;
      if (stats.direction === 'BULLISH') bullishCount++;
      if (stats.direction === 'BEARISH') bearishCount++;
      countedCoins++;
    }
  }

  const avgMomentum = countedCoins > 0 ? Number((totalMomentum / countedCoins).toFixed(2)) : 0;
  const volumeChange = countedCoins > 0 ? Number((totalVolChange / countedCoins).toFixed(2)) : 0;
  const rawScore = countedCoins > 0 ? Math.round(totalScore / countedCoins) : 50;
  const score = Math.max(0, Math.min(100, rawScore));

  let status: 'Bullish' | 'Neutral' | 'Bearish' = 'Neutral';
  if (score >= 65 || (bullishCount > bearishCount && avgMomentum > 1.5)) {
    status = 'Bullish';
  } else if (score <= 45 || (bearishCount > bullishCount && avgMomentum < -1.5)) {
    status = 'Bearish';
  }

  return {
    id: sector.id,
    name: sector.name,
    coins: sector.coins,
    avgMomentum,
    volumeChange,
    bullishCount,
    bearishCount,
    score,
    status,
  };
}
