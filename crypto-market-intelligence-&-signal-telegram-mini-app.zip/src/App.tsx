import { useState, useEffect, useCallback } from 'react';
import {
  initTelegramApp,
  getTelegramUser,
  triggerHaptic,
} from './lib/telegram.ts';
import { Header } from './components/Header.tsx';
import { BottomNavigation, ScreenTab } from './components/BottomNavigation.tsx';
import { DashboardView } from './components/DashboardView.tsx';
import { SignalsView } from './components/SignalsView.tsx';
import { SectorsView } from './components/SectorsView.tsx';
import { MarketView } from './components/MarketView.tsx';
import { WatchlistView } from './components/WatchlistView.tsx';
import { HistoryView } from './components/HistoryView.tsx';
import { ProfileView } from './components/ProfileView.tsx';
import { SettingsView } from './components/SettingsView.tsx';
import { AdminView } from './components/AdminView.tsx';
import { CoinDetailModal } from './components/CoinDetailModal.tsx';
import {
  MarketOverview,
  Coin,
  Signal,
  SectorData,
  BacktestRecord,
  UserSettings,
  SystemStatus,
} from './types/crypto.ts';

export default function App() {
  const [currentTab, setCurrentTab] = useState<ScreenTab>('dashboard');
  const [marketOverview, setMarketOverview] = useState<MarketOverview | null>(null);
  const [allCoins, setAllCoins] = useState<Coin[]>([]);
  const [signals, setSignals] = useState<Signal[]>([]);
  const [sectors, setSectors] = useState<SectorData[]>([]);
  const [history, setHistory] = useState<BacktestRecord[]>([]);
  const [watchlist, setWatchlist] = useState<string[]>(['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'BNBUSDT']);
  const [settings, setSettings] = useState<UserSettings>({
    userId: 'default_user',
    bullishAlerts: true,
    bearishAlerts: true,
    highScoreAlerts: true,
    sectorAlerts: true,
    minScore: 70,
    lastUpdated: Date.now(),
  });
  const [systemStatus, setSystemStatus] = useState<SystemStatus | null>(null);

  const [selectedCoin, setSelectedCoin] = useState<Coin | null>(null);
  const [selectedSignal, setSelectedSignal] = useState<Signal | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const telegramUser = getTelegramUser();

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Fetch Core Data
  const fetchData = useCallback(async (background: boolean = false) => {
    if (!background) setIsScanning(true);
    try {
      const [overviewRes, coinsRes, signalsRes, sectorsRes, historyRes, statusRes] =
        await Promise.all([
          fetch('/api/market/overview').then((r) => r.json()),
          fetch('/api/market/coins').then((r) => r.json()),
          fetch('/api/signals').then((r) => r.json()),
          fetch('/api/sectors').then((r) => r.json()),
          fetch('/api/history').then((r) => r.json()),
          fetch('/api/system/status').then((r) => r.json()),
        ]);

      if (overviewRes && !overviewRes.error) setMarketOverview(overviewRes);
      if (Array.isArray(coinsRes)) setAllCoins(coinsRes);
      if (Array.isArray(signalsRes)) setSignals(signalsRes);
      if (Array.isArray(sectorsRes)) setSectors(sectorsRes);
      if (Array.isArray(historyRes)) setHistory(historyRes);
      if (statusRes && !statusRes.error) setSystemStatus(statusRes);
    } catch (err) {
      console.error('Failed to fetch market data:', err);
    } finally {
      if (!background) setIsScanning(false);
    }
  }, []);

  // Initialize on mount
  useEffect(() => {
    initTelegramApp();
    fetchData(false);

    // Auto-refresh market data every 20 seconds
    const interval = setInterval(() => {
      fetchData(true);
    }, 20000);

    return () => clearInterval(interval);
  }, [fetchData]);

  // Watchlist toggle handler
  const handleToggleWatchlist = async (symbol: string) => {
    try {
      const res = await fetch('/api/watchlist/toggle', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ symbol, userId: String(telegramUser.id) }),
      });
      const data = await res.json();
      if (data.watchlist) {
        setWatchlist(data.watchlist);
        const added = data.watchlist.includes(symbol);
        showToast(added ? `⭐ Added ${symbol} to Watchlist` : `Removed ${symbol} from Watchlist`);
      }
    } catch (err) {
      console.error('Watchlist toggle error:', err);
    }
  };

  // Settings update handler
  const handleUpdateSettings = async (updates: Partial<UserSettings>) => {
    try {
      const res = await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: String(telegramUser.id), updates }),
      });
      const data = await res.json();
      if (data) {
        setSettings(data);
        showToast('Settings saved successfully.');
      }
    } catch (err) {
      console.error('Settings update error:', err);
    }
  };

  // Manual Trigger Scan
  const handleTriggerScan = async () => {
    setIsScanning(true);
    try {
      const res = await fetch('/api/admin/trigger-scan', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        showToast(`Market scan complete! ${data.signalsCount} setups evaluated.`);
        await fetchData(false);
      }
    } catch (err: any) {
      showToast(`Scan error: ${err.message}`);
    } finally {
      setIsScanning(false);
    }
  };

  // Execute Telegram Bot Command (Simulator)
  const handleExecuteCommand = async (command: string) => {
    const res = await fetch('/api/telegram/command', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ command, chatId: String(telegramUser.id) }),
    });
    return await res.json();
  };

  // Dispatch Test Alert
  const handleSendTestNotification = async () => {
    try {
      const res = await fetch('/api/telegram/test-alert', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chatId: String(telegramUser.id) }),
      });
      const data = await res.json();
      if (data.success) {
        showToast('🚀 Alert notification dispatched successfully!');
      } else {
        showToast(`Alert notice: ${data.reason || 'Simulation recorded'}`);
      }
    } catch (err: any) {
      showToast(`Error: ${err.message}`);
    }
  };

  // Coin selection
  const handleSelectCoin = (coin: Coin) => {
    const sig = signals.find((s) => s.symbol === coin.symbol) || null;
    setSelectedCoin(coin);
    setSelectedSignal(sig);
  };

  const handleSelectSignal = (sig: Signal) => {
    const coin = allCoins.find((c) => c.symbol === sig.symbol) || null;
    setSelectedCoin(coin);
    setSelectedSignal(sig);
  };

  const handleSelectCoinSymbol = (symbol: string) => {
    const coin = allCoins.find((c) => c.symbol === symbol);
    if (coin) handleSelectCoin(coin);
  };

  const bullishCount = signals.filter((s) => s.direction === 'BULLISH').length;
  const bearishCount = signals.filter((s) => s.direction === 'BEARISH').length;

  return (
    <div className="min-h-screen bg-[#0b0e14] text-slate-100 flex flex-col font-sans">
      {/* Toast Alert popup */}
      {toastMessage && (
        <div className="fixed top-14 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs shadow-xl shadow-amber-500/20 animate-in fade-in duration-150">
          {toastMessage}
        </div>
      )}

      {/* Header */}
      <Header
        btcPrice={marketOverview?.btcPrice || 0}
        btcChange24h={marketOverview?.btcChange24h || 0}
        isScanning={isScanning}
        onRefresh={handleTriggerScan}
        telegramUser={telegramUser}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-lg w-full mx-auto px-3 pt-2">
        {currentTab === 'dashboard' && marketOverview && (
          <DashboardView
            data={marketOverview}
            onSelectCoin={handleSelectCoin}
            onSelectSignal={handleSelectSignal}
            onNavigate={(tab) => {
              triggerHaptic('light');
              setCurrentTab(tab);
            }}
          />
        )}

        {(currentTab === 'bullish' || currentTab === 'bearish') && (
          <SignalsView
            signals={signals}
            initialDirection={currentTab === 'bearish' ? 'BEARISH' : 'BULLISH'}
            onSelectSignal={handleSelectSignal}
          />
        )}

        {currentTab === 'sectors' && (
          <SectorsView
            sectors={sectors}
            onSelectCoinSymbol={handleSelectCoinSymbol}
          />
        )}

        {currentTab === 'market' && (
          <MarketView
            coins={allCoins}
            watchlist={watchlist}
            onToggleWatchlist={handleToggleWatchlist}
            onSelectCoin={handleSelectCoin}
          />
        )}

        {currentTab === 'watchlist' && (
          <WatchlistView
            watchlistSymbols={watchlist}
            allCoins={allCoins}
            signals={signals}
            onToggleWatchlist={handleToggleWatchlist}
            onSelectCoin={handleSelectCoin}
            onSelectSignal={handleSelectSignal}
          />
        )}

        {currentTab === 'history' && (
          <HistoryView records={history} />
        )}

        {currentTab === 'profile' && (
          <ProfileView
            user={telegramUser}
            onSendTestNotification={handleSendTestNotification}
          />
        )}

        {currentTab === 'settings' && (
          <div className="space-y-4">
            {/* Quick Profile / Admin Switcher */}
            <div className="flex items-center justify-between p-1 bg-slate-900 rounded-xl border border-slate-800 text-xs">
              <button
                onClick={() => setCurrentTab('settings')}
                className="flex-1 py-1.5 rounded-lg font-bold bg-amber-500/20 text-amber-300"
              >
                Settings & Bot
              </button>
              <button
                onClick={() => setCurrentTab('profile')}
                className="flex-1 py-1.5 rounded-lg font-semibold text-slate-400 hover:text-slate-200"
              >
                Telegram Profile
              </button>
              <button
                onClick={() => setCurrentTab('admin')}
                className="flex-1 py-1.5 rounded-lg font-semibold text-slate-400 hover:text-slate-200"
              >
                System Health
              </button>
            </div>

            <SettingsView
              settings={settings}
              onUpdateSettings={handleUpdateSettings}
              onExecuteCommand={handleExecuteCommand}
            />
          </div>
        )}

        {currentTab === 'admin' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between p-1 bg-slate-900 rounded-xl border border-slate-800 text-xs">
              <button
                onClick={() => setCurrentTab('settings')}
                className="flex-1 py-1.5 rounded-lg font-semibold text-slate-400 hover:text-slate-200"
              >
                Settings & Bot
              </button>
              <button
                onClick={() => setCurrentTab('profile')}
                className="flex-1 py-1.5 rounded-lg font-semibold text-slate-400 hover:text-slate-200"
              >
                Telegram Profile
              </button>
              <button
                onClick={() => setCurrentTab('admin')}
                className="flex-1 py-1.5 rounded-lg font-bold bg-rose-500/20 text-rose-300"
              >
                System Health
              </button>
            </div>

            <AdminView
              status={systemStatus}
              onTriggerScan={handleTriggerScan}
            />
          </div>
        )}
      </main>

      {/* Bottom Navigation */}
      <BottomNavigation
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        bullishCount={bullishCount}
        bearishCount={bearishCount}
      />

      {/* Coin Detail & Technical Analysis Modal */}
      {selectedCoin && (
        <CoinDetailModal
          coin={selectedCoin}
          signal={selectedSignal}
          watchlist={watchlist}
          onToggleWatchlist={handleToggleWatchlist}
          onClose={() => {
            setSelectedCoin(null);
            setSelectedSignal(null);
          }}
        />
      )}
    </div>
  );
}
