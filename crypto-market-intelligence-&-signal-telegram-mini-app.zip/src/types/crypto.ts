export interface Candle {
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface Coin {
  symbol: string;
  name: string;
  baseAsset: string;
  price: number;
  change24h: number;
  high24h: number;
  low24h: number;
  volume24h: number;
  quoteVolume24h: number;
  sector: string;
  lastUpdated: number;
}

export interface IndicatorValues {
  rsi: number;
  macd: {
    macd: number;
    signal: number;
    histogram: number;
  };
  ema20: number;
  ema50: number;
  ema200: number;
  sma20: number;
  sma50: number;
  atr: number;
  volumeChange: number; // percentage vs 20-period avg
  momentum: number; // percentage price change
  volatility: number;
  support: number;
  resistance: number;
}

export type SignalDirection = 'BULLISH' | 'BEARISH' | 'NEUTRAL';
export type SignalClassification = 'Strong Setup' | 'Moderate Setup' | 'Watchlist' | 'No Signal';
export type SignalRisk = 'LOW' | 'MEDIUM' | 'HIGH';
export type TimeFrame = '12H' | '24H';

export interface Signal {
  id: string;
  coin: string;
  symbol: string;
  timestamp: number;
  expiresAt: number;
  timeframe: TimeFrame;
  direction: SignalDirection;
  score: number; // 0 - 100
  classification: SignalClassification;
  risk: SignalRisk;
  reasons: string[];
  indicators: IndicatorValues;
  priceAtSignal: number;
  status: 'ACTIVE' | 'EXPIRED' | 'TARGET_REACHED' | 'INVALIDATED';
  disclaimer: string;
}

export interface SectorData {
  id: string;
  name: string;
  coins: string[];
  avgMomentum: number;
  volumeChange: number;
  bullishCount: number;
  bearishCount: number;
  score: number; // 0 - 100
  status: 'Bullish' | 'Neutral' | 'Bearish';
}

export interface BacktestRecord {
  id: string;
  signalId: string;
  symbol: string;
  direction: SignalDirection;
  score: number;
  timeframe: TimeFrame;
  signalTime: number;
  entryPrice: number;
  price1h: number;
  price6h: number;
  price12h: number;
  price24h: number;
  change1hPct: number;
  change6hPct: number;
  change12hPct: number;
  change24hPct: number;
  outcome: 'FAVORABLE' | 'NEUTRAL' | 'ADVERSE';
  notes: string;
}

export interface UserSettings {
  userId: string;
  bullishAlerts: boolean;
  bearishAlerts: boolean;
  highScoreAlerts: boolean;
  sectorAlerts: boolean;
  minScore: 60 | 70 | 80 | 90;
  telegramChatId?: string;
  lastUpdated: number;
}

export interface SystemStatus {
  exchangeConnected: boolean;
  databaseConnected: boolean;
  telegramBotConfigured: boolean;
  lastDataUpdate: number;
  lastSignalGen: number;
  activeSignalsCount: {
    total: number;
    bullish: number;
    bearish: number;
  };
  totalCoinsMonitored: number;
  rateLimitWeight: number;
  errorLogs: Array<{
    timestamp: number;
    service: string;
    message: string;
  }>;
}

export interface MarketOverview {
  btcPrice: number;
  btcChange24h: number;
  ethPrice: number;
  ethChange24h: number;
  totalMarketTrend: 'Bullish' | 'Bearish' | 'Neutral';
  bullishSignalCount: number;
  bearishSignalCount: number;
  highMomentumCoins: Coin[];
  topVolumeCoins: Coin[];
  latestSignals: Signal[];
  sectors: SectorData[];
  lastUpdated: number;
}
