import { useState } from 'react';
import { Search, ArrowUpDown, TrendingUp, TrendingDown, Star } from 'lucide-react';
import { Coin } from '../types/crypto.ts';
import { triggerHaptic } from '../lib/telegram.ts';

interface MarketViewProps {
  coins: Coin[];
  watchlist: string[];
  onToggleWatchlist: (symbol: string) => void;
  onSelectCoin: (coin: Coin) => void;
}

export function MarketView({
  coins,
  watchlist,
  onToggleWatchlist,
  onSelectCoin,
}: MarketViewProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'volume' | 'change' | 'price'>('volume');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  const filteredCoins = coins
    .filter((coin) => {
      const q = searchQuery.toLowerCase();
      return (
        coin.symbol.toLowerCase().includes(q) ||
        coin.baseAsset.toLowerCase().includes(q) ||
        coin.sector.toLowerCase().includes(q)
      );
    })
    .sort((a, b) => {
      let diff = 0;
      if (sortBy === 'volume') diff = b.quoteVolume24h - a.quoteVolume24h;
      if (sortBy === 'change') diff = b.change24h - a.change24h;
      if (sortBy === 'price') diff = b.price - a.price;
      return sortOrder === 'desc' ? diff : -diff;
    });

  const handleSortChange = (newSort: 'volume' | 'change' | 'price') => {
    triggerHaptic('light');
    if (sortBy === newSort) {
      setSortOrder(sortOrder === 'desc' ? 'asc' : 'desc');
    } else {
      setSortBy(newSort);
      setSortOrder('desc');
    }
  };

  return (
    <div className="space-y-3 pb-20 pt-2">
      {/* Search Input */}
      <div className="relative">
        <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
        <input
          type="text"
          id="market-search-input"
          placeholder="Search coins (BTC, SOL, AI, Meme)..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-amber-500/50"
        />
      </div>

      {/* Sort Buttons */}
      <div className="flex items-center justify-between px-1 text-xs text-slate-400">
        <span className="font-medium">{filteredCoins.length} Assets</span>
        <div className="flex items-center gap-1.5">
          <span className="text-[11px]">Sort:</span>
          {(['volume', 'change', 'price'] as const).map((type) => (
            <button
              key={type}
              onClick={() => handleSortChange(type)}
              className={`px-2 py-0.5 rounded capitalize font-medium transition-all ${
                sortBy === type
                  ? 'bg-amber-500/20 text-amber-300 font-semibold'
                  : 'hover:text-slate-200'
              }`}
            >
              {type} {sortBy === type && (sortOrder === 'desc' ? '↓' : '↑')}
            </button>
          ))}
        </div>
      </div>

      {/* Coin List Cards */}
      <div className="space-y-2">
        {filteredCoins.map((coin) => {
          const isPositive = coin.change24h >= 0;
          const isWatched = watchlist.includes(coin.symbol);

          return (
            <div
              key={coin.symbol}
              id={`coin-row-${coin.symbol}`}
              onClick={() => {
                triggerHaptic('light');
                onSelectCoin(coin);
              }}
              className="p-3.5 rounded-xl bg-slate-900/75 border border-slate-800/80 hover:border-slate-700 active:scale-[0.99] transition-all cursor-pointer flex items-center justify-between"
            >
              <div className="flex items-center gap-3">
                <button
                  id={`btn-star-${coin.symbol}`}
                  onClick={(e) => {
                    e.stopPropagation();
                    triggerHaptic('medium');
                    onToggleWatchlist(coin.symbol);
                  }}
                  className="p-1 text-slate-500 hover:text-amber-400 transition-colors"
                >
                  <Star
                    className={`w-4 h-4 ${
                      isWatched ? 'fill-amber-400 text-amber-400' : 'text-slate-500'
                    }`}
                  />
                </button>

                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-sm text-slate-100">{coin.baseAsset}</span>
                    <span className="text-[10px] font-medium text-slate-400 px-1.5 py-0.2 rounded bg-slate-800">
                      {coin.sector}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    Vol: ${(coin.quoteVolume24h / 1e6).toFixed(1)}M
                  </div>
                </div>
              </div>

              <div className="text-right">
                <div className="font-bold text-sm text-slate-100">
                  ${coin.price < 1 ? coin.price.toFixed(4) : coin.price.toLocaleString()}
                </div>
                <div
                  className={`text-xs font-bold mt-0.5 flex items-center justify-end gap-0.5 ${
                    isPositive ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {isPositive ? (
                    <TrendingUp className="w-3 h-3 inline" />
                  ) : (
                    <TrendingDown className="w-3 h-3 inline" />
                  )}
                  <span>
                    {isPositive ? '+' : ''}
                    {coin.change24h}%
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
