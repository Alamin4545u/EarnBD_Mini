import { useState } from 'react';
import {
  Boxes,
  TrendingUp,
  TrendingDown,
  Activity,
  ArrowUpRight,
  ShieldCheck,
  Cpu,
  Layers,
  Coins,
  Gamepad2,
  Building,
  Radio,
} from 'lucide-react';
import { SectorData } from '../types/crypto.ts';
import { DisclaimerBanner } from './DisclaimerBanner.tsx';
import { triggerHaptic } from '../lib/telegram.ts';

interface SectorsViewProps {
  sectors: SectorData[];
  onSelectCoinSymbol?: (symbol: string) => void;
}

export function SectorsView({ sectors, onSelectCoinSymbol }: SectorsViewProps) {
  const [selectedSectorId, setSelectedSectorId] = useState<string | null>(null);

  const getSectorIcon = (id: string) => {
    switch (id) {
      case 'ai':
        return Cpu;
      case 'layer1':
        return Layers;
      case 'layer2':
        return Boxes;
      case 'defi':
        return Coins;
      case 'meme':
        return TrendingUp;
      case 'gaming':
        return Gamepad2;
      case 'rwa':
        return Building;
      case 'depin':
        return Radio;
      default:
        return Activity;
    }
  };

  return (
    <div className="space-y-4 pb-20 pt-2">
      <DisclaimerBanner compact />

      {/* Header Info */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-purple-950/40 via-slate-900 to-slate-900 border border-purple-500/20">
        <div className="flex items-center gap-2 mb-1">
          <Boxes className="w-5 h-5 text-purple-400" />
          <h2 className="text-base font-bold text-slate-100">Crypto Sector Radar</h2>
        </div>
        <p className="text-xs text-slate-300 leading-relaxed">
          Tracking 8 major market sectors. Aggregate momentum, volume shifts, and relative strength across market cycles.
        </p>
      </div>

      {/* Sectors Grid */}
      <div className="space-y-3">
        {sectors.map((sec) => {
          const Icon = getSectorIcon(sec.id);
          const isBullish = sec.status === 'Bullish';
          const isBearish = sec.status === 'Bearish';
          const isSelected = selectedSectorId === sec.id;

          return (
            <div
              key={sec.id}
              id={`sector-card-${sec.id}`}
              onClick={() => {
                triggerHaptic('light');
                setSelectedSectorId(isSelected ? null : sec.id);
              }}
              className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-slate-700 transition-all cursor-pointer shadow-sm"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold ${
                      isBullish
                        ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                        : isBearish
                        ? 'bg-rose-500/15 text-rose-400 border border-rose-500/30'
                        : 'bg-purple-500/15 text-purple-400 border border-purple-500/30'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-sm font-bold text-slate-100">{sec.name}</h3>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          isBullish
                            ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                            : isBearish
                            ? 'bg-rose-500/15 text-rose-400 border border-rose-500/30'
                            : 'bg-slate-700/30 text-slate-300 border border-slate-700/50'
                        }`}
                      >
                        {sec.status}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 mt-0.5">
                      {sec.coins.length} core assets monitored
                    </p>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-lg font-black text-amber-400">
                    {sec.score}<span className="text-[10px] text-slate-400 font-normal">/100</span>
                  </div>
                  <div className="text-[10px] text-slate-400 font-medium">Sector Score</div>
                </div>
              </div>

              {/* Metrics Row */}
              <div className="grid grid-cols-3 gap-2 mt-3 p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/60 text-xs text-center">
                <div>
                  <div className="text-[10px] text-slate-400">Avg Momentum</div>
                  <div
                    className={`font-bold mt-0.5 ${
                      sec.avgMomentum >= 0 ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {sec.avgMomentum >= 0 ? '+' : ''}
                    {sec.avgMomentum}%
                  </div>
                </div>

                <div>
                  <div className="text-[10px] text-slate-400">Vol Change</div>
                  <div
                    className={`font-bold mt-0.5 ${
                      sec.volumeChange >= 0 ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {sec.volumeChange >= 0 ? '+' : ''}
                    {sec.volumeChange}%
                  </div>
                </div>

                <div>
                  <div className="text-[10px] text-slate-400">Setups Confluence</div>
                  <div className="font-bold mt-0.5 flex items-center justify-center gap-1.5">
                    <span className="text-emerald-400 font-semibold">{sec.bullishCount} 🟢</span>
                    <span className="text-rose-400 font-semibold">{sec.bearishCount} 🔴</span>
                  </div>
                </div>
              </div>

              {/* Coins List Pill Row */}
              <div className="mt-3 flex items-center gap-1.5 flex-wrap">
                <span className="text-[10px] text-slate-400 font-medium mr-1">Assets:</span>
                {sec.coins.map((coinSymbol) => (
                  <button
                    key={coinSymbol}
                    onClick={(e) => {
                      e.stopPropagation();
                      triggerHaptic('light');
                      if (onSelectCoinSymbol) onSelectCoinSymbol(coinSymbol);
                    }}
                    className="px-2 py-0.5 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-medium transition-colors"
                  >
                    {coinSymbol.replace('USDT', '')}
                  </button>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
