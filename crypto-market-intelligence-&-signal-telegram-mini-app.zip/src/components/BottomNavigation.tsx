import {
  LayoutDashboard,
  TrendingUp,
  LineChart,
  Boxes,
  Star,
  History,
  Settings,
} from 'lucide-react';
import { triggerHaptic } from '../lib/telegram.ts';

export type ScreenTab =
  | 'dashboard'
  | 'bullish'
  | 'bearish'
  | 'sectors'
  | 'market'
  | 'watchlist'
  | 'history'
  | 'profile'
  | 'settings'
  | 'admin';

interface BottomNavigationProps {
  currentTab: ScreenTab;
  onSelectTab: (tab: ScreenTab) => void;
  bullishCount: number;
  bearishCount: number;
}

export function BottomNavigation({
  currentTab,
  onSelectTab,
  bullishCount,
  bearishCount,
}: BottomNavigationProps) {
  const isSignalsActive = currentTab === 'bullish' || currentTab === 'bearish';

  const navItems = [
    {
      id: 'dashboard' as ScreenTab,
      label: 'Home',
      icon: LayoutDashboard,
    },
    {
      id: 'bullish' as ScreenTab,
      label: 'Signals',
      icon: TrendingUp,
      badge: bullishCount + bearishCount,
      isActiveOverride: isSignalsActive,
    },
    {
      id: 'market' as ScreenTab,
      label: 'Market',
      icon: LineChart,
    },
    {
      id: 'sectors' as ScreenTab,
      label: 'Sectors',
      icon: Boxes,
    },
    {
      id: 'watchlist' as ScreenTab,
      label: 'Watchlist',
      icon: Star,
    },
    {
      id: 'history' as ScreenTab,
      label: 'History',
      icon: History,
    },
    {
      id: 'settings' as ScreenTab,
      label: 'Settings',
      icon: Settings,
    },
  ];

  return (
    <nav
      id="bottom-navigation-bar"
      className="fixed bottom-0 left-0 right-0 z-40 bg-[#0b0e14]/95 backdrop-blur-lg border-t border-slate-800/80 px-2 py-1.5 max-w-lg mx-auto"
    >
      <div className="grid grid-cols-7 gap-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = item.isActiveOverride !== undefined ? item.isActiveOverride : currentTab === item.id;

          return (
            <button
              key={item.id}
              id={`nav-btn-${item.id}`}
              onClick={() => {
                triggerHaptic('light');
                onSelectTab(item.id);
              }}
              className={`flex flex-col items-center justify-center py-1 px-0.5 rounded-lg transition-all relative ${
                isActive
                  ? 'text-amber-400 font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <div className="relative">
                <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.5px]' : 'stroke-[1.8px]'}`} />
                {item.badge !== undefined && item.badge > 0 && (
                  <span className="absolute -top-1 -right-2 bg-amber-500 text-slate-950 text-[9px] font-bold px-1 py-0.2 rounded-full min-w-[14px] text-center leading-none">
                    {item.badge}
                  </span>
                )}
              </div>
              <span className="text-[10px] mt-1 tracking-tight truncate w-full text-center">
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
