import { User, Shield, Bell, Send, CheckCircle, Smartphone } from 'lucide-react';
import { isRunningInTelegram, triggerHaptic } from '../lib/telegram.ts';

interface ProfileViewProps {
  user: {
    id: number;
    first_name: string;
    last_name?: string;
    username?: string;
    language_code?: string;
    photo_url?: string;
  };
  onSendTestNotification: () => void;
}

export function ProfileView({ user, onSendTestNotification }: ProfileViewProps) {
  const inTelegram = isRunningInTelegram();

  return (
    <div className="space-y-4 pb-20 pt-2">
      {/* Profile Card */}
      <div className="p-5 rounded-2xl bg-gradient-to-br from-slate-900 to-[#121824] border border-slate-800 shadow-md text-center relative overflow-hidden">
        <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-amber-500 to-amber-300 mx-auto flex items-center justify-center text-slate-950 font-black text-2xl shadow-lg shadow-amber-500/20">
          {user.photo_url ? (
            <img src={user.photo_url} alt="Profile" className="w-full h-full rounded-full object-cover" />
          ) : (
            user.first_name.charAt(0).toUpperCase()
          )}
        </div>

        <h2 className="text-lg font-bold text-slate-100 mt-3">
          {user.first_name} {user.last_name || ''}
        </h2>
        {user.username && (
          <p className="text-xs text-amber-400 font-medium">@{user.username}</p>
        )}

        <div className="flex items-center justify-center gap-2 mt-3">
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-500/15 text-amber-300 border border-amber-500/30">
            <Shield className="w-3 h-3" /> VIP Trader Member
          </span>
          <span
            className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold ${
              inTelegram
                ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                : 'bg-blue-500/15 text-blue-400 border border-blue-500/30'
            }`}
          >
            <Smartphone className="w-3 h-3" /> {inTelegram ? 'Telegram Native' : 'Browser Mode'}
          </span>
        </div>
      </div>

      {/* Account Details */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3 text-xs">
        <div className="font-semibold text-slate-300 text-[11px] uppercase tracking-wider">
          Telegram Session Metadata
        </div>

        <div className="flex justify-between py-1.5 border-b border-slate-800/80">
          <span className="text-slate-400">Telegram User ID:</span>
          <span className="font-mono font-semibold text-slate-200">{user.id}</span>
        </div>

        <div className="flex justify-between py-1.5 border-b border-slate-800/80">
          <span className="text-slate-400">Language Code:</span>
          <span className="font-semibold text-slate-200 uppercase">{user.language_code || 'en'}</span>
        </div>

        <div className="flex justify-between py-1.5 border-b border-slate-800/80">
          <span className="text-slate-400">Signal Access Tier:</span>
          <span className="font-semibold text-emerald-400">Unlimited (All 8 Sectors)</span>
        </div>

        <div className="flex justify-between py-1.5">
          <span className="text-slate-400">Spam Cooldown Status:</span>
          <span className="font-semibold text-blue-400">Active (4-hour anti-repeat)</span>
        </div>
      </div>

      {/* Test Notification Trigger */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3">
        <div className="flex items-center gap-2">
          <Bell className="w-4 h-4 text-amber-400" />
          <h3 className="text-sm font-bold text-slate-100">Telegram Bot Alert Testing</h3>
        </div>
        <p className="text-xs text-slate-400">
          Send a formatted test alert message to verify notification delivery and WebApp inline buttons.
        </p>
        <button
          id="btn-profile-test-alert"
          onClick={() => {
            triggerHaptic('medium');
            onSendTestNotification();
          }}
          className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 active:scale-98 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-md shadow-amber-500/20"
        >
          <Send className="w-4 h-4" />
          <span>Dispatch Test Alert Now</span>
        </button>
      </div>
    </div>
  );
}
