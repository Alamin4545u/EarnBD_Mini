import { useState, useEffect } from 'react';
import {
  X,
  TrendingUp,
  TrendingDown,
  BarChart2,
  Sliders,
  ShieldAlert,
  Clock,
  ExternalLink,
  ChevronRight,
  Star,
} from 'lucide-react';
import { Coin, Signal, Candle } from '../types/crypto.ts';
import { triggerHaptic } from '../lib/telegram.ts';

interface CoinDetailModalProps {
  coin: Coin | null;
  signal: Signal | null;
  watchlist: string[];
  onToggleWatchlist: (symbol: string) => void;
  onClose: () => void;
}

export function CoinDetailModal({
  coin,
  signal,
  watchlist,
  onToggleWatchlist,
  onClose,
}: CoinDetailModalProps) {
  const [interval, setInterval] = useState<'15m' | '1h' | '4h'>('1h');
  const [candles, setCandles] = useState<Candle[]>([]);
  const [loadingCandles, setLoadingCandles] = useState(false);

  useEffect(() => {
    if (!coin) return;
    setLoadingCandles(true);
    fetch(`/api/market/coin/${coin.symbol}?interval=${interval}`)
      .then((res) => res.json())
      .then((data) => {
        if (data.candles) setCandles(data.candles);
      })
      .catch((err) => console.error('Error fetching candles:', err))
      .finally(() => setLoadingCandles(false));
  }, [coin, interval]);

  if (!coin) return null;

  const isPositive = coin.change24h >= 0;
  const isWatched = watchlist.includes(coin.symbol);
  const ind = signal?.indicators;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div
        id="coin-detail-modal"
        className="w-full max-w-lg bg-[#0d111a] border border-slate-800 rounded-t-3xl sm:rounded-3xl max-h-[90vh] overflow-y-auto p-4 space-y-4 shadow-2xl animate-in slide-in-from-bottom duration-200"
      >
        {/* Header */}
        <div className="flex items-start justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-black text-slate-100">{coin.symbol}</h2>
                <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-slate-800 text-slate-300">
                  {coin.sector}
                </span>
                <button
                  onClick={() => {
                    triggerHaptic('medium');
                    onToggleWatchlist(coin.symbol);
                  }}
                  className="p-1 text-slate-400 hover:text-amber-400 transition-colors"
                >
                  <Star className={`w-4 h-4 ${isWatched ? 'fill-amber-400 text-amber-400' : ''}`} />
                </button>
              </div>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-2xl font-bold text-slate-100">
                  ${coin.price < 1 ? coin.price.toFixed(4) : coin.price.toLocaleString()}
                </span>
                <span
                  className={`text-xs font-bold ${
                    isPositive ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {isPositive ? '+' : ''}
                  {coin.change24h}%
                </span>
              </div>
            </div>
          </div>

          <button
            onClick={() => {
              triggerHaptic('light');
              onClose();
            }}
            className="p-2 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 24h High, Low & Volume stats */}
        <div className="grid grid-cols-3 gap-2 p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80 text-xs text-center">
          <div>
            <div className="text-[10px] text-slate-400">24H High</div>
            <div className="font-semibold text-slate-200 mt-0.5">
              ${coin.high24h < 1 ? coin.high24h.toFixed(4) : coin.high24h.toLocaleString()}
            </div>
          </div>

          <div>
            <div className="text-[10px] text-slate-400">24H Low</div>
            <div className="font-semibold text-slate-200 mt-0.5">
              ${coin.low24h < 1 ? coin.low24h.toFixed(4) : coin.low24h.toLocaleString()}
            </div>
          </div>

          <div>
            <div className="text-[10px] text-slate-400">24H Volume</div>
            <div className="font-semibold text-slate-200 mt-0.5">
              ${(coin.quoteVolume24h / 1e6).toFixed(1)}M
            </div>
          </div>
        </div>

        {/* Timeframe selector */}
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-slate-400">Candle Horizon:</span>
          <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-lg border border-slate-800">
            {(['15m', '1h', '4h'] as const).map((tf) => (
              <button
                key={tf}
                onClick={() => {
                  triggerHaptic('light');
                  setInterval(tf);
                }}
                className={`px-3 py-1 rounded text-xs font-semibold transition-all ${
                  interval === tf
                    ? 'bg-amber-500 text-slate-950'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {tf}
              </button>
            ))}
          </div>
        </div>

        {/* Candle mini bar preview */}
        <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-[11px] text-slate-400">
            <span>Recent Price Action ({interval})</span>
            {loadingCandles && <span className="text-amber-400 animate-pulse">Updating...</span>}
          </div>

          <div className="h-16 flex items-end gap-1 pt-2">
            {candles.slice(-24).map((c, i) => {
              const candleBull = c.close >= c.open;
              const range = Math.max(...candles.map((x) => x.high)) - Math.min(...candles.map((x) => x.low)) || 1;
              const minPrice = Math.min(...candles.map((x) => x.low));
              const heightPct = Math.max(10, Math.min(100, ((c.close - minPrice) / range) * 100));

              return (
                <div
                  key={i}
                  className="flex-1 flex flex-col justify-end items-center h-full group relative"
                >
                  <div
                    style={{ height: `${heightPct}%` }}
                    className={`w-full rounded-t-sm transition-all ${
                      candleBull ? 'bg-emerald-500/80 group-hover:bg-emerald-400' : 'bg-rose-500/80 group-hover:bg-rose-400'
                    }`}
                  />
                </div>
              );
            })}
          </div>
        </div>

        {/* Active Signal Details if available */}
        {signal ? (
          <div
            className={`p-4 rounded-2xl border space-y-3 ${
              signal.direction === 'BULLISH'
                ? 'bg-emerald-950/20 border-emerald-500/30'
                : 'bg-rose-950/20 border-rose-500/30'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {signal.direction === 'BULLISH' ? (
                  <TrendingUp className="w-5 h-5 text-emerald-400" />
                ) : (
                  <TrendingDown className="w-5 h-5 text-rose-400" />
                )}
                <div>
                  <h3 className="text-sm font-bold text-slate-100">
                    {signal.direction === 'BULLISH' ? 'Bullish Setup Detected' : 'Bearish Setup Detected'}
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    {signal.timeframe} Horizon • Risk: {signal.risk}
                  </p>
                </div>
              </div>

              <div className="text-right">
                <div className="text-lg font-black text-amber-400">{signal.score}/100</div>
                <div className="text-[10px] text-slate-400 font-medium">{signal.classification}</div>
              </div>
            </div>

            <div className="space-y-1 text-xs">
              <div className="text-[11px] font-semibold text-slate-300 uppercase">
                Confluence Factors:
              </div>
              {signal.reasons.map((r, idx) => (
                <div key={idx} className="flex items-start gap-2 text-slate-300">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-1.5 shrink-0" />
                  <span>{r}</span>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 text-center text-xs text-slate-400">
            No active high-conviction signal on this coin. Currently in neutral consolidation range.
          </div>
        )}

        {/* Technical Indicators Confluence Panel */}
        {ind && (
          <div className="space-y-2 pt-2">
            <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
              Technical Indicators Confluence
            </h3>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-2.5 rounded-xl bg-slate-900/70 border border-slate-800 flex justify-between">
                <span className="text-slate-400">RSI (14 Wilder):</span>
                <span
                  className={`font-bold ${
                    ind.rsi > 70 ? 'text-rose-400' : ind.rsi < 30 ? 'text-emerald-400' : 'text-slate-200'
                  }`}
                >
                  {ind.rsi.toFixed(1)}
                </span>
              </div>

              <div className="p-2.5 rounded-xl bg-slate-900/70 border border-slate-800 flex justify-between">
                <span className="text-slate-400">MACD Histogram:</span>
                <span
                  className={`font-bold ${
                    ind.macd.histogram >= 0 ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {ind.macd.histogram.toFixed(3)}
                </span>
              </div>

              <div className="p-2.5 rounded-xl bg-slate-900/70 border border-slate-800 flex justify-between">
                <span className="text-slate-400">EMA 20:</span>
                <span className="font-semibold text-slate-200">
                  ${ind.ema20 < 1 ? ind.ema20.toFixed(4) : ind.ema20.toLocaleString()}
                </span>
              </div>

              <div className="p-2.5 rounded-xl bg-slate-900/70 border border-slate-800 flex justify-between">
                <span className="text-slate-400">EMA 50:</span>
                <span className="font-semibold text-slate-200">
                  ${ind.ema50 < 1 ? ind.ema50.toFixed(4) : ind.ema50.toLocaleString()}
                </span>
              </div>

              <div className="p-2.5 rounded-xl bg-slate-900/70 border border-slate-800 flex justify-between">
                <span className="text-slate-400">EMA 200:</span>
                <span className="font-semibold text-slate-200">
                  ${ind.ema200 < 1 ? ind.ema200.toFixed(4) : ind.ema200.toLocaleString()}
                </span>
              </div>

              <div className="p-2.5 rounded-xl bg-slate-900/70 border border-slate-800 flex justify-between">
                <span className="text-slate-400">ATR (14):</span>
                <span className="font-semibold text-slate-200">
                  ${ind.atr < 1 ? ind.atr.toFixed(4) : ind.atr.toFixed(2)}
                </span>
              </div>

              <div className="p-2.5 rounded-xl bg-slate-900/70 border border-slate-800 flex justify-between">
                <span className="text-slate-400">Support Pivot:</span>
                <span className="font-bold text-emerald-400">
                  ${ind.support < 1 ? ind.support.toFixed(4) : ind.support.toLocaleString()}
                </span>
              </div>

              <div className="p-2.5 rounded-xl bg-slate-900/70 border border-slate-800 flex justify-between">
                <span className="text-slate-400">Resistance Pivot:</span>
                <span className="font-bold text-rose-400">
                  ${ind.resistance < 1 ? ind.resistance.toFixed(4) : ind.resistance.toLocaleString()}
                </span>
              </div>
            </div>
          </div>
        )}

        {/* Disclaimer footer */}
        <div className="pt-2 text-[11px] text-slate-400 italic text-center border-t border-slate-800">
          ⚠️ Algorithmic analysis only. Not financial advice or guaranteed price prediction.
        </div>
      </div>
    </div>
  );
}
