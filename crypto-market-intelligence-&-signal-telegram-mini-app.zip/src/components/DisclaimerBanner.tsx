import { AlertTriangle } from 'lucide-react';

interface DisclaimerBannerProps {
  compact?: boolean;
}

export function DisclaimerBanner({ compact = false }: DisclaimerBannerProps) {
  if (compact) {
    return (
      <div
        id="disclaimer-banner-compact"
        className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs"
      >
        <AlertTriangle className="w-3.5 h-3.5 shrink-0 text-amber-400" />
        <span className="leading-tight">
          Market analysis only. Signals are algorithmic indicators, not guaranteed predictions or financial advice.
        </span>
      </div>
    );
  }

  return (
    <div
      id="disclaimer-banner-full"
      className="p-3.5 rounded-xl bg-slate-900/80 border border-amber-500/20 text-slate-300 text-xs flex items-start gap-3 shadow-sm"
    >
      <div className="w-6 h-6 rounded-md bg-amber-500/15 flex items-center justify-center shrink-0 mt-0.5">
        <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
      </div>
      <div className="space-y-0.5">
        <p className="font-semibold text-amber-300">Algorithmic Market Intelligence Notice</p>
        <p className="text-slate-400 leading-relaxed">
          Crypto markets are highly volatile. This application computes technical indicator confluence, volume profiles, and momentum setups. It does not predict future prices with certainty. Never invest more than you can afford to lose.
        </p>
      </div>
    </div>
  );
}
