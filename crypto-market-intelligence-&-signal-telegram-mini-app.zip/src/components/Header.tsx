import { RefreshCw, Zap, ShieldAlert } from 'lucide-react';
import { triggerHaptic } from '../lib/telegram.ts';

interface HeaderProps {
  btcPrice: number;
  btcChange24h: number;
  isScanning: boolean;
  onRefresh: () => void;
  telegramUser: {
    first_name: string;
    username?: string;
  };
}

export function Header({
  btcPrice,
  btcChange24h,
  isScanning,
  onRefresh,
  telegramUser,
}: HeaderProps) {
  const isBtcPositive = btcChange24h >= 0;

  return (
    <header
      id="app-header"
      className="sticky top-0 z-40 bg-[#0b0e14]/90 backdrop-blur-md border-b border-slate-800/80 px-4 py-3 flex items-center justify-between"
    >
      <div className="flex items-center gap-2.5">
        <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-amber-600 to-amber-400 flex items-center justify-center text-slate-950 font-bold text-sm shadow-sm shadow-amber-500/20">
          <Zap className="w-4 h-4 fill-slate-950" />
        </div>
        <div>
          <div className="flex items-center gap-1.5">
            <h1 className="text-sm font-semibold text-slate-100 tracking-tight">
              CryptoIntel
            </h1>
            <span className="inline-flex items-center px-1.5 py-0.2 rounded text-[10px] font-medium bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
              LIVE
            </span>
          </div>
          <p className="text-[11px] text-slate-400 truncate max-w-[130px]">
            {telegramUser.first_name ? `Hi, ${telegramUser.first_name}` : 'Telegram Mini App'}
          </p>
        </div>
      </div>

      <div className="flex items-center gap-2">
        {/* BTC Ticker Pill */}
        {btcPrice > 0 && (
          <div
            id="btc-header-ticker"
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-900/90 border border-slate-800 text-xs"
          >
            <span className="font-medium text-slate-300">BTC</span>
            <span className="font-semibold text-slate-100">
              ${btcPrice > 1000 ? btcPrice.toLocaleString('en-US', { maximumFractionDigits: 0 }) : btcPrice.toFixed(2)}
            </span>
            <span
              className={`text-[11px] font-medium ${
                isBtcPositive ? 'text-emerald-400' : 'text-rose-400'
              }`}
            >
              {isBtcPositive ? '+' : ''}
              {btcChange24h.toFixed(1)}%
            </span>
          </div>
        )}

        {/* Refresh scan button */}
        <button
          id="btn-header-refresh"
          onClick={() => {
            triggerHaptic('light');
            onRefresh();
          }}
          disabled={isScanning}
          title="Rescan market data"
          className="w-8 h-8 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-300 hover:text-white hover:bg-slate-800 active:scale-95 transition-all disabled:opacity-50"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isScanning ? 'animate-spin text-amber-400' : ''}`} />
        </button>
      </div>
    </header>
  );
}
