import { Star, Plus, Trash2, TrendingUp, TrendingDown, Bell } from 'lucide-react';
import { Coin, Signal } from '../types/crypto.ts';
import { triggerHaptic } from '../lib/telegram.ts';

interface WatchlistViewProps {
  watchlistSymbols: string[];
  allCoins: Coin[];
  signals: Signal[];
  onToggleWatchlist: (symbol: string) => void;
  onSelectCoin: (coin: Coin) => void;
  onSelectSignal: (signal: Signal) => void;
}

export function WatchlistView({
  watchlistSymbols,
  allCoins,
  signals,
  onToggleWatchlist,
  onSelectCoin,
  onSelectSignal,
}: WatchlistViewProps) {
  const watchedCoins = watchlistSymbols
    .map((sym) => allCoins.find((c) => c.symbol === sym))
    .filter((c): c is Coin => c !== undefined);

  const unwatchedCoins = allCoins.filter((c) => !watchlistSymbols.includes(c.symbol));

  const signalMap = new Map<string, Signal>();
  for (const sig of signals) {
    signalMap.set(sig.symbol, sig);
  }

  return (
    <div className="space-y-4 pb-20 pt-2">
      {/* Header card */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-950/30 via-slate-900 to-slate-900 border border-amber-500/20 flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2">
            <Star className="w-5 h-5 text-amber-400 fill-amber-400" />
            <h2 className="text-base font-bold text-slate-100">Personalized Watchlist</h2>
          </div>
          <p className="text-xs text-slate-300 mt-1">
            Tracking {watchedCoins.length} priority assets. Real-time setup alerts are routed here.
          </p>
        </div>
      </div>

      {/* Watched Assets List */}
      <div className="space-y-2.5">
        {watchedCoins.length === 0 ? (
          <div className="p-8 rounded-2xl bg-slate-900/60 border border-slate-800 text-center space-y-2">
            <Star className="w-8 h-8 mx-auto text-slate-600" />
            <p className="text-sm font-semibold text-slate-300">Your watchlist is empty</p>
            <p className="text-xs text-slate-400">
              Star coins below or from the Market tab to monitor priority market setups.
            </p>
          </div>
        ) : (
          watchedCoins.map((coin) => {
            const isPositive = coin.change24h >= 0;
            const activeSignal = signalMap.get(coin.symbol);

            return (
              <div
                key={coin.symbol}
                id={`watchlist-item-${coin.symbol}`}
                onClick={() => {
                  triggerHaptic('light');
                  onSelectCoin(coin);
                }}
                className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-slate-700 transition-all cursor-pointer"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        triggerHaptic('medium');
                        onToggleWatchlist(coin.symbol);
                      }}
                      className="p-1 text-amber-400 hover:text-rose-400 transition-colors"
                      title="Remove from watchlist"
                    >
                      <Star className="w-4 h-4 fill-amber-400" />
                    </button>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-sm text-slate-100">{coin.baseAsset}</span>
                        <span className="text-[10px] text-slate-400 px-1.5 py-0.2 rounded bg-slate-800">
                          {coin.sector}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-400 mt-0.5">
                        Vol: ${(coin.quoteVolume24h / 1e6).toFixed(1)}M
                      </div>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="font-bold text-sm text-slate-100">
                      ${coin.price < 1 ? coin.price.toFixed(4) : coin.price.toLocaleString()}
                    </div>
                    <div
                      className={`text-xs font-bold ${
                        isPositive ? 'text-emerald-400' : 'text-rose-400'
                      }`}
                    >
                      {isPositive ? '+' : ''}
                      {coin.change24h}%
                    </div>
                  </div>
                </div>

                {/* Active Setup Badge if detected */}
                {activeSignal && (
                  <div
                    onClick={(e) => {
                      e.stopPropagation();
                      triggerHaptic('medium');
                      onSelectSignal(activeSignal);
                    }}
                    className={`mt-2.5 p-2 rounded-lg text-xs font-medium flex items-center justify-between transition-opacity hover:opacity-90 ${
                      activeSignal.direction === 'BULLISH'
                        ? 'bg-emerald-950/40 text-emerald-300 border border-emerald-500/30'
                        : 'bg-rose-950/40 text-rose-300 border border-rose-500/30'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 truncate">
                      {activeSignal.direction === 'BULLISH' ? (
                        <TrendingUp className="w-3.5 h-3.5 shrink-0 text-emerald-400" />
                      ) : (
                        <TrendingDown className="w-3.5 h-3.5 shrink-0 text-rose-400" />
                      )}
                      <span className="truncate">
                        {activeSignal.direction === 'BULLISH' ? 'Bullish Setup' : 'Bearish Setup'} (Score: {activeSignal.score}/100)
                      </span>
                    </div>
                    <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-slate-900 shrink-0 ml-1">
                      {activeSignal.timeframe}
                    </span>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Add More Assets Section */}
      {unwatchedCoins.length > 0 && (
        <div className="pt-2">
          <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2 px-1">
            Add to Watchlist
          </h3>
          <div className="flex flex-wrap gap-1.5">
            {unwatchedCoins.slice(0, 8).map((coin) => (
              <button
                key={coin.symbol}
                onClick={() => {
                  triggerHaptic('light');
                  onToggleWatchlist(coin.symbol);
                }}
                className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 text-xs font-semibold text-slate-300 hover:text-white hover:border-slate-700 flex items-center gap-1.5 transition-all"
              >
                <Plus className="w-3 h-3 text-amber-400" />
                <span>{coin.baseAsset}</span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
