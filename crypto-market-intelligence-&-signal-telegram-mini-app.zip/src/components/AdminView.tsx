import { useState } from 'react';
import {
  ShieldAlert,
  Server,
  Database,
  Radio,
  RefreshCw,
  CheckCircle,
  XCircle,
  AlertOctagon,
  Cpu,
  Clock,
  Send,
} from 'lucide-react';
import { SystemStatus } from '../types/crypto.ts';
import { triggerHaptic } from '../lib/telegram.ts';

interface AdminViewProps {
  status: SystemStatus | null;
  onTriggerScan: () => Promise<void>;
}

export function AdminView({ status, onTriggerScan }: AdminViewProps) {
  const [isScanning, setIsScanning] = useState(false);
  const [scanMessage, setScanMessage] = useState<string | null>(null);

  const handleScan = async () => {
    setIsScanning(true);
    setScanMessage(null);
    triggerHaptic('medium');
    try {
      await onTriggerScan();
      setScanMessage('Algorithmic scan completed successfully.');
    } catch (err: any) {
      setScanMessage(`Scan error: ${err.message}`);
    } finally {
      setIsScanning(false);
    }
  };

  const lastUpdateStr = status?.lastDataUpdate
    ? new Date(status.lastDataUpdate).toLocaleTimeString()
    : 'Never';
  const lastSignalStr = status?.lastSignalGen
    ? new Date(status.lastSignalGen).toLocaleTimeString()
    : 'Never';

  return (
    <div className="space-y-4 pb-20 pt-2">
      {/* Header */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-red-950/30 via-slate-900 to-slate-900 border border-red-500/20 flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2">
            <Server className="w-5 h-5 text-rose-400" />
            <h2 className="text-base font-bold text-slate-100">System Monitoring & Health</h2>
          </div>
          <p className="text-xs text-slate-300 mt-1">
            Real-time diagnostics across Binance, Firestore, and Telegram pipelines.
          </p>
        </div>
      </div>

      {/* Connection Status Grid */}
      <div className="grid grid-cols-3 gap-2">
        <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 text-center">
          <div className="text-[10px] text-slate-400 font-semibold uppercase">Binance Feed</div>
          <div className="flex items-center justify-center gap-1.5 mt-1">
            {status?.exchangeConnected ? (
              <>
                <CheckCircle className="w-4 h-4 text-emerald-400" />
                <span className="text-xs font-bold text-emerald-400">Connected</span>
              </>
            ) : (
              <>
                <XCircle className="w-4 h-4 text-rose-400" />
                <span className="text-xs font-bold text-rose-400">Offline</span>
              </>
            )}
          </div>
        </div>

        <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 text-center">
          <div className="text-[10px] text-slate-400 font-semibold uppercase">Database</div>
          <div className="flex items-center justify-center gap-1.5 mt-1">
            <Database className="w-4 h-4 text-emerald-400" />
            <span className="text-xs font-bold text-emerald-400">Ready</span>
          </div>
        </div>

        <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 text-center">
          <div className="text-[10px] text-slate-400 font-semibold uppercase">Telegram Bot</div>
          <div className="flex items-center justify-center gap-1.5 mt-1">
            {status?.telegramBotConfigured ? (
              <>
                <Radio className="w-4 h-4 text-emerald-400" />
                <span className="text-xs font-bold text-emerald-400">Active</span>
              </>
            ) : (
              <>
                <Radio className="w-4 h-4 text-amber-400" />
                <span className="text-xs font-bold text-amber-400">Simulation</span>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Metrics Summary */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3 text-xs">
        <div className="font-semibold text-slate-300 text-[11px] uppercase tracking-wider">
          Engine Statistics
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800">
            <div className="text-slate-400 text-[10px]">Monitored Assets</div>
            <div className="text-base font-bold text-slate-100 mt-0.5">
              {status?.totalCoinsMonitored || 20} Coins
            </div>
          </div>

          <div className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800">
            <div className="text-slate-400 text-[10px]">Active Setups</div>
            <div className="text-base font-bold text-slate-100 mt-0.5">
              {status?.activeSignalsCount.total || 0} Total
              <span className="text-xs font-normal text-slate-400 ml-1">
                ({status?.activeSignalsCount.bullish || 0} 🟢 / {status?.activeSignalsCount.bearish || 0} 🔴)
              </span>
            </div>
          </div>

          <div className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800">
            <div className="text-slate-400 text-[10px]">Last Binance Sync</div>
            <div className="text-xs font-semibold text-slate-200 mt-0.5">{lastUpdateStr}</div>
          </div>

          <div className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800">
            <div className="text-slate-400 text-[10px]">Last Signal Engine Run</div>
            <div className="text-xs font-semibold text-slate-200 mt-0.5">{lastSignalStr}</div>
          </div>
        </div>

        {/* Manual Trigger Button */}
        <div className="pt-2 border-t border-slate-800">
          <button
            id="btn-admin-trigger-scan"
            onClick={handleScan}
            disabled={isScanning}
            className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 active:scale-98 disabled:opacity-50 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-md shadow-amber-500/20"
          >
            <RefreshCw className={`w-4 h-4 ${isScanning ? 'animate-spin' : ''}`} />
            <span>{isScanning ? 'Executing Algorithmic Scan...' : 'Trigger Immediate Market Re-Scan'}</span>
          </button>
          {scanMessage && (
            <p className="text-[11px] text-emerald-400 text-center mt-2 font-medium">
              {scanMessage}
            </p>
          )}
        </div>
      </div>

      {/* System Error Logs */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2">
        <div className="flex items-center gap-2">
          <AlertOctagon className="w-4 h-4 text-slate-400" />
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
            Diagnostics & Log Output
          </h3>
        </div>

        {(!status?.errorLogs || status.errorLogs.length === 0) ? (
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800/80 text-center text-xs text-emerald-400 font-medium">
            ✓ All microservices running smoothly. No network or rate-limit warnings recorded.
          </div>
        ) : (
          <div className="space-y-1.5 max-h-40 overflow-y-auto">
            {status.errorLogs.map((log, idx) => (
              <div
                key={idx}
                className="p-2 rounded-lg bg-slate-950 border border-slate-800 text-[11px] font-mono text-slate-300"
              >
                <span className="text-amber-400 font-semibold">[{log.service}]</span> {log.message}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
