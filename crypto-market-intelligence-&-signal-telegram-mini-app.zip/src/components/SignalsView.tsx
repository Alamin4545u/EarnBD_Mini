import { useState } from 'react';
import {
  TrendingUp,
  TrendingDown,
  ShieldCheck,
  ShieldAlert,
  Clock,
  ChevronDown,
  ChevronUp,
  BarChart2,
  SlidersHorizontal,
  ExternalLink,
} from 'lucide-react';
import { Signal, SignalDirection, TimeFrame } from '../types/crypto.ts';
import { DisclaimerBanner } from './DisclaimerBanner.tsx';
import { triggerHaptic } from '../lib/telegram.ts';

interface SignalsViewProps {
  signals: Signal[];
  initialDirection?: SignalDirection;
  onSelectSignal: (signal: Signal) => void;
}

export function SignalsView({
  signals,
  initialDirection = 'BULLISH',
  onSelectSignal,
}: SignalsViewProps) {
  const [activeDirection, setActiveDirection] = useState<SignalDirection>(initialDirection);
  const [selectedTimeframe, setSelectedTimeframe] = useState<string>('ALL');
  const [selectedScoreTier, setSelectedScoreTier] = useState<string>('ALL');
  const [expandedSignalId, setExpandedSignalId] = useState<string | null>(null);

  // Filter signals
  const filtered = signals.filter((s) => {
    if (s.direction !== activeDirection) return false;
    if (selectedTimeframe !== 'ALL' && s.timeframe !== selectedTimeframe) return false;
    if (selectedScoreTier === 'STRONG' && s.score < 80) return false;
    if (selectedScoreTier === 'MODERATE' && (s.score < 65 || s.score >= 80)) return false;
    return true;
  });

  const isBullishMode = activeDirection === 'BULLISH';

  return (
    <div className="space-y-4 pb-20 pt-2">
      {/* Disclaimer */}
      <DisclaimerBanner />

      {/* Direction Switcher (Bullish vs Bearish) */}
      <div
        id="signals-direction-toggle"
        className="grid grid-cols-2 gap-2 p-1 bg-slate-900/90 rounded-xl border border-slate-800"
      >
        <button
          id="tab-bullish-setups"
          onClick={() => {
            triggerHaptic('light');
            setActiveDirection('BULLISH');
          }}
          className={`py-2 px-3 rounded-lg text-xs font-bold flex items-center justify-center gap-2 transition-all ${
            isBullishMode
              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 shadow-sm'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <TrendingUp className="w-4 h-4" />
          <span>Bullish Setups ({signals.filter((s) => s.direction === 'BULLISH').length})</span>
        </button>

        <button
          id="tab-bearish-setups"
          onClick={() => {
            triggerHaptic('light');
            setActiveDirection('BEARISH');
          }}
          className={`py-2 px-3 rounded-lg text-xs font-bold flex items-center justify-center gap-2 transition-all ${
            !isBullishMode
              ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30 shadow-sm'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <TrendingDown className="w-4 h-4" />
          <span>Bearish Setups ({signals.filter((s) => s.direction === 'BEARISH').length})</span>
        </button>
      </div>

      {/* Filter Row: Timeframe & Score Tiers */}
      <div className="flex items-center justify-between gap-2 text-xs">
        {/* Timeframe pill selector */}
        <div className="flex items-center gap-1 bg-slate-900/70 p-1 rounded-lg border border-slate-800">
          <Clock className="w-3.5 h-3.5 text-slate-400 ml-1" />
          {(['ALL', '12H', '24H'] as const).map((tf) => (
            <button
              key={tf}
              onClick={() => {
                triggerHaptic('light');
                setSelectedTimeframe(tf);
              }}
              className={`px-2 py-0.5 rounded text-[11px] font-medium transition-all ${
                selectedTimeframe === tf
                  ? 'bg-amber-500/20 text-amber-300 font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {tf}
            </button>
          ))}
        </div>

        {/* Score Tier selector */}
        <div className="flex items-center gap-1 bg-slate-900/70 p-1 rounded-lg border border-slate-800">
          {(['ALL', 'STRONG', 'MODERATE'] as const).map((tier) => (
            <button
              key={tier}
              onClick={() => {
                triggerHaptic('light');
                setSelectedScoreTier(tier);
              }}
              className={`px-2 py-0.5 rounded text-[11px] font-medium transition-all ${
                selectedScoreTier === tier
                  ? 'bg-amber-500/20 text-amber-300 font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {tier === 'STRONG' ? '80+ Strong' : tier === 'MODERATE' ? '65-79 Mod' : 'All Scores'}
            </button>
          ))}
        </div>
      </div>

      {/* Signals List */}
      <div className="space-y-3">
        {filtered.length === 0 ? (
          <div className="p-8 rounded-2xl bg-slate-900/60 border border-slate-800 text-center space-y-2">
            <ShieldCheck className="w-8 h-8 mx-auto text-slate-500" />
            <h3 className="text-sm font-semibold text-slate-300">
              No matching {isBullishMode ? 'bullish' : 'bearish'} setups
            </h3>
            <p className="text-xs text-slate-400 max-w-xs mx-auto">
              Our algorithm maintains strict multi-indicator confluence thresholds. Try changing the timeframe or score filter.
            </p>
          </div>
        ) : (
          filtered.map((sig) => {
            const isExpanded = expandedSignalId === sig.id;
            const timeRemainingHours = Math.max(
              0,
              Math.round((sig.expiresAt - Date.now()) / (3600 * 1000))
            );

            return (
              <div
                key={sig.id}
                id={`signal-card-${sig.symbol}`}
                className="rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-slate-700 transition-all overflow-hidden shadow-sm"
              >
                {/* Card Header */}
                <div className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-11 h-11 rounded-xl flex items-center justify-center font-bold ${
                          isBullishMode
                            ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                            : 'bg-rose-500/15 text-rose-400 border border-rose-500/30'
                        }`}
                      >
                        {isBullishMode ? (
                          <TrendingUp className="w-6 h-6" />
                        ) : (
                          <TrendingDown className="w-6 h-6" />
                        )}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="text-base font-bold text-slate-100">{sig.symbol}</h3>
                          <span className="text-[11px] font-semibold text-slate-300 px-2 py-0.5 rounded-full bg-slate-800 border border-slate-700">
                            {sig.timeframe}
                          </span>
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                              sig.risk === 'LOW'
                                ? 'bg-blue-500/15 text-blue-300 border border-blue-500/30'
                                : sig.risk === 'MEDIUM'
                                ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                                : 'bg-rose-500/15 text-rose-300 border border-rose-500/30'
                            }`}
                          >
                            {sig.risk} RISK
                          </span>
                        </div>
                        <p className="text-xs font-medium text-slate-400 mt-0.5">
                          Price at scan: ${sig.priceAtSignal < 1 ? sig.priceAtSignal.toFixed(4) : sig.priceAtSignal.toLocaleString()} • Valid {timeRemainingHours}h
                        </p>
                      </div>
                    </div>

                    {/* Score Ring */}
                    <div className="text-right">
                      <div
                        className={`text-xl font-black ${
                          sig.score >= 80
                            ? 'text-emerald-400'
                            : sig.score >= 65
                            ? 'text-amber-400'
                            : 'text-slate-300'
                        }`}
                      >
                        {sig.score}
                        <span className="text-xs text-slate-400 font-normal">/100</span>
                      </div>
                      <div className="text-[10px] font-semibold text-slate-400 uppercase tracking-tight">
                        {sig.classification}
                      </div>
                    </div>
                  </div>

                  {/* Supporting Reasons List */}
                  <div className="mt-3.5 space-y-1.5 p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/60 text-xs">
                    <div className="font-semibold text-slate-300 text-[11px] uppercase tracking-wider mb-1">
                      Confluence Reasons
                    </div>
                    {sig.reasons.map((r, i) => (
                      <div key={i} className="flex items-start gap-2 text-slate-300 leading-snug">
                        <span
                          className={`w-1.5 h-1.5 rounded-full mt-1.5 shrink-0 ${
                            isBullishMode ? 'bg-emerald-400' : 'bg-rose-400'
                          }`}
                        />
                        <span>{r}</span>
                      </div>
                    ))}
                  </div>

                  {/* Action buttons */}
                  <div className="flex items-center justify-between mt-3 pt-2 border-t border-slate-800/80">
                    <button
                      onClick={() => {
                        triggerHaptic('light');
                        setExpandedSignalId(isExpanded ? null : sig.id);
                      }}
                      className="text-xs font-semibold text-slate-400 hover:text-slate-200 flex items-center gap-1"
                    >
                      <span>{isExpanded ? 'Hide' : 'Show'} Technical Breakdown</span>
                      {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                    </button>

                    <button
                      id={`btn-analyze-${sig.symbol}`}
                      onClick={() => {
                        triggerHaptic('medium');
                        onSelectSignal(sig);
                      }}
                      className="px-3 py-1 rounded-lg bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-bold hover:bg-amber-500/25 flex items-center gap-1.5 active:scale-95 transition-all"
                    >
                      <span>Analyze Chart</span>
                      <ExternalLink className="w-3 h-3" />
                    </button>
                  </div>
                </div>

                {/* Technical Indicators Breakdown (Expandable Drawer) */}
                {isExpanded && (
                  <div className="p-4 bg-slate-950/80 border-t border-slate-800 text-xs space-y-3">
                    <div className="grid grid-cols-3 gap-2">
                      <div className="p-2 rounded-lg bg-slate-900/80 border border-slate-800">
                        <div className="text-[10px] text-slate-400">RSI (14)</div>
                        <div className="text-sm font-bold text-slate-100 mt-0.5">
                          {sig.indicators.rsi.toFixed(1)}
                        </div>
                      </div>

                      <div className="p-2 rounded-lg bg-slate-900/80 border border-slate-800">
                        <div className="text-[10px] text-slate-400">MACD Hist</div>
                        <div
                          className={`text-sm font-bold mt-0.5 ${
                            sig.indicators.macd.histogram >= 0 ? 'text-emerald-400' : 'text-rose-400'
                          }`}
                        >
                          {sig.indicators.macd.histogram.toFixed(3)}
                        </div>
                      </div>

                      <div className="p-2 rounded-lg bg-slate-900/80 border border-slate-800">
                        <div className="text-[10px] text-slate-400">Vol vs Avg</div>
                        <div
                          className={`text-sm font-bold mt-0.5 ${
                            sig.indicators.volumeChange >= 0 ? 'text-emerald-400' : 'text-rose-400'
                          }`}
                        >
                          {sig.indicators.volumeChange >= 0 ? '+' : ''}
                          {sig.indicators.volumeChange.toFixed(0)}%
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-[11px]">
                      <div className="p-2 rounded-lg bg-slate-900/80 border border-slate-800 flex justify-between">
                        <span className="text-slate-400">EMA 20:</span>
                        <span className="font-semibold text-slate-200">
                          ${sig.indicators.ema20 < 1 ? sig.indicators.ema20.toFixed(4) : sig.indicators.ema20.toLocaleString()}
                        </span>
                      </div>
                      <div className="p-2 rounded-lg bg-slate-900/80 border border-slate-800 flex justify-between">
                        <span className="text-slate-400">EMA 50:</span>
                        <span className="font-semibold text-slate-200">
                          ${sig.indicators.ema50 < 1 ? sig.indicators.ema50.toFixed(4) : sig.indicators.ema50.toLocaleString()}
                        </span>
                      </div>
                      <div className="p-2 rounded-lg bg-slate-900/80 border border-slate-800 flex justify-between">
                        <span className="text-slate-400">Key Support:</span>
                        <span className="font-semibold text-emerald-400">
                          ${sig.indicators.support < 1 ? sig.indicators.support.toFixed(4) : sig.indicators.support.toLocaleString()}
                        </span>
                      </div>
                      <div className="p-2 rounded-lg bg-slate-900/80 border border-slate-800 flex justify-between">
                        <span className="text-slate-400">Key Resistance:</span>
                        <span className="font-semibold text-rose-400">
                          ${sig.indicators.resistance < 1 ? sig.indicators.resistance.toFixed(4) : sig.indicators.resistance.toLocaleString()}
                        </span>
                      </div>
                    </div>

                    <p className="text-[10px] text-slate-400 italic">
                      {sig.disclaimer}
                    </p>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
