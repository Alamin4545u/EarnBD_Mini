import {
  TrendingUp,
  TrendingDown,
  Activity,
  Zap,
  BarChart3,
  ArrowRight,
  ShieldAlert,
  Flame,
  Globe2,
} from 'lucide-react';
import { MarketOverview, Coin, Signal } from '../types/crypto.ts';
import { DisclaimerBanner } from './DisclaimerBanner.tsx';
import { ScreenTab } from './BottomNavigation.tsx';
import { triggerHaptic } from '../lib/telegram.ts';

interface DashboardViewProps {
  data: MarketOverview;
  onSelectCoin: (coin: Coin) => void;
  onSelectSignal: (signal: Signal) => void;
  onNavigate: (tab: ScreenTab) => void;
}

export function DashboardView({
  data,
  onSelectCoin,
  onSelectSignal,
  onNavigate,
}: DashboardViewProps) {
  const isTrendBullish = data.totalMarketTrend === 'Bullish';
  const isTrendBearish = data.totalMarketTrend === 'Bearish';

  return (
    <div className="space-y-4 pb-20 pt-2">
      {/* Disclaimer */}
      <DisclaimerBanner compact />

      {/* Hero Market Pulse Card */}
      <div
        id="dashboard-hero-card"
        className="p-4 rounded-2xl bg-gradient-to-br from-slate-900 to-[#121722] border border-slate-800 shadow-md relative overflow-hidden"
      >
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-amber-400" />
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              Market Sentiment Radar
            </span>
          </div>
          <div
            className={`px-2.5 py-0.5 rounded-full text-xs font-bold flex items-center gap-1 ${
              isTrendBullish
                ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                : isTrendBearish
                ? 'bg-rose-500/15 text-rose-400 border border-rose-500/30'
                : 'bg-slate-700/30 text-slate-300 border border-slate-700/50'
            }`}
          >
            {isTrendBullish ? (
              <TrendingUp className="w-3.5 h-3.5" />
            ) : isTrendBearish ? (
              <TrendingDown className="w-3.5 h-3.5" />
            ) : (
              <Activity className="w-3.5 h-3.5" />
            )}
            {data.totalMarketTrend} Trend
          </div>
        </div>

        {/* BTC & ETH Grid */}
        <div className="grid grid-cols-2 gap-3 pt-1">
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80">
            <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
              <span>Bitcoin (BTC)</span>
              <span
                className={`font-semibold ${
                  data.btcChange24h >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {data.btcChange24h >= 0 ? '+' : ''}
                {data.btcChange24h.toFixed(2)}%
              </span>
            </div>
            <div className="text-lg font-bold text-slate-100">
              ${data.btcPrice.toLocaleString('en-US', { maximumFractionDigits: 0 })}
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80">
            <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
              <span>Ethereum (ETH)</span>
              <span
                className={`font-semibold ${
                  data.ethChange24h >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {data.ethChange24h >= 0 ? '+' : ''}
                {data.ethChange24h.toFixed(2)}%
              </span>
            </div>
            <div className="text-lg font-bold text-slate-100">
              ${data.ethPrice.toLocaleString('en-US', { maximumFractionDigits: 2 })}
            </div>
          </div>
        </div>

        {/* Active Setups Counter Cards */}
        <div className="grid grid-cols-2 gap-3 mt-3">
          <button
            id="btn-dash-bullish-setups"
            onClick={() => {
              triggerHaptic('light');
              onNavigate('bullish');
            }}
            className="p-3 rounded-xl bg-emerald-950/25 border border-emerald-500/25 text-left hover:bg-emerald-950/40 transition-all flex items-center justify-between group"
          >
            <div>
              <div className="text-xs font-medium text-emerald-300">Bullish Setups</div>
              <div className="text-2xl font-black text-emerald-400 mt-0.5">
                {data.bullishSignalCount}
              </div>
              <div className="text-[10px] text-emerald-400/80">Upside momentum</div>
            </div>
            <ArrowRight className="w-4 h-4 text-emerald-400 group-hover:translate-x-1 transition-transform" />
          </button>

          <button
            id="btn-dash-bearish-setups"
            onClick={() => {
              triggerHaptic('light');
              onNavigate('bearish');
            }}
            className="p-3 rounded-xl bg-rose-950/25 border border-rose-500/25 text-left hover:bg-rose-950/40 transition-all flex items-center justify-between group"
          >
            <div>
              <div className="text-xs font-medium text-rose-300">Bearish Setups</div>
              <div className="text-2xl font-black text-rose-400 mt-0.5">
                {data.bearishSignalCount}
              </div>
              <div className="text-[10px] text-rose-400/80">Downside risk</div>
            </div>
            <ArrowRight className="w-4 h-4 text-rose-400 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </div>

      {/* Latest Signals Stream */}
      <div>
        <div className="flex items-center justify-between mb-2.5 px-1">
          <div className="flex items-center gap-1.5">
            <Zap className="w-4 h-4 text-amber-400" />
            <h2 className="text-sm font-bold text-slate-200">Latest Algorithmic Setups</h2>
          </div>
          <button
            onClick={() => onNavigate('bullish')}
            className="text-xs text-amber-400 hover:text-amber-300 flex items-center gap-1 font-medium"
          >
            View All <ArrowRight className="w-3 h-3" />
          </button>
        </div>

        {data.latestSignals.length === 0 ? (
          <div className="p-6 rounded-xl bg-slate-900/60 border border-slate-800 text-center text-xs text-slate-400">
            Analyzing orderbooks and candles... Setups will appear shortly.
          </div>
        ) : (
          <div className="space-y-2">
            {data.latestSignals.slice(0, 4).map((sig) => {
              const isBullish = sig.direction === 'BULLISH';
              return (
                <div
                  key={sig.id}
                  id={`latest-sig-${sig.symbol}`}
                  onClick={() => {
                    triggerHaptic('light');
                    onSelectSignal(sig);
                  }}
                  className="p-3 rounded-xl bg-slate-900/70 border border-slate-800 hover:border-slate-700 active:scale-[0.99] transition-all cursor-pointer flex items-center justify-between"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-9 h-9 rounded-lg flex items-center justify-center font-bold text-xs ${
                        isBullish
                          ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                          : 'bg-rose-500/15 text-rose-400 border border-rose-500/30'
                      }`}
                    >
                      {isBullish ? <TrendingUp className="w-5 h-5" /> : <TrendingDown className="w-5 h-5" />}
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-sm text-slate-100">{sig.symbol}</span>
                        <span className="text-[11px] font-medium text-slate-400 px-1.5 py-0.2 rounded bg-slate-800">
                          {sig.timeframe}
                        </span>
                        <span
                          className={`text-[10px] font-bold px-1.5 py-0.2 rounded ${
                            sig.risk === 'LOW'
                              ? 'bg-blue-500/15 text-blue-300'
                              : sig.risk === 'MEDIUM'
                              ? 'bg-amber-500/15 text-amber-300'
                              : 'bg-rose-500/15 text-rose-300'
                          }`}
                        >
                          {sig.risk} RISK
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 line-clamp-1 mt-0.5">
                        {sig.reasons[1] || sig.reasons[0]}
                      </p>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="text-sm font-bold text-amber-400">
                      {sig.score}<span className="text-[10px] text-slate-400">/100</span>
                    </div>
                    <span className="text-[10px] text-slate-400 font-medium">
                      {sig.classification}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* High Momentum Coins */}
      <div>
        <div className="flex items-center justify-between mb-2.5 px-1">
          <div className="flex items-center gap-1.5">
            <Flame className="w-4 h-4 text-orange-400" />
            <h2 className="text-sm font-bold text-slate-200">High Momentum Coins</h2>
          </div>
          <button
            onClick={() => onNavigate('market')}
            className="text-xs text-slate-400 hover:text-slate-200 flex items-center gap-1"
          >
            All Coins <ArrowRight className="w-3 h-3" />
          </button>
        </div>

        <div className="grid grid-cols-2 gap-2">
          {data.highMomentumCoins.slice(0, 4).map((coin) => (
            <div
              key={coin.symbol}
              onClick={() => {
                triggerHaptic('light');
                onSelectCoin(coin);
              }}
              className="p-3 rounded-xl bg-slate-900/60 border border-slate-800/80 hover:border-slate-700 cursor-pointer active:scale-98 transition-all"
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-slate-200">{coin.baseAsset}</span>
                <span
                  className={`text-xs font-bold ${
                    coin.change24h >= 0 ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {coin.change24h >= 0 ? '+' : ''}
                  {coin.change24h}%
                </span>
              </div>
              <div className="text-sm font-semibold text-slate-100 mt-1">
                ${coin.price < 1 ? coin.price.toFixed(4) : coin.price.toLocaleString()}
              </div>
              <div className="text-[10px] text-slate-400 truncate mt-0.5">
                Vol: ${(coin.quoteVolume24h / 1e6).toFixed(1)}M
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Top Volume Coins */}
      <div>
        <div className="flex items-center justify-between mb-2.5 px-1">
          <div className="flex items-center gap-1.5">
            <BarChart3 className="w-4 h-4 text-sky-400" />
            <h2 className="text-sm font-bold text-slate-200">Top 24H Volume</h2>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-2">
          {data.topVolumeCoins.slice(0, 3).map((coin) => (
            <div
              key={coin.symbol}
              onClick={() => onSelectCoin(coin)}
              className="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800 text-center cursor-pointer hover:border-slate-700"
            >
              <div className="font-bold text-xs text-slate-200">{coin.baseAsset}</div>
              <div className="text-xs font-semibold text-slate-100 mt-0.5">
                ${coin.price < 1 ? coin.price.toFixed(4) : coin.price.toLocaleString()}
              </div>
              <div className="text-[10px] text-sky-400 mt-0.5 font-medium">
                ${(coin.quoteVolume24h / 1e6).toFixed(0)}M
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Sector Overview Quick Widget */}
      <div>
        <div className="flex items-center justify-between mb-2.5 px-1">
          <div className="flex items-center gap-1.5">
            <Globe2 className="w-4 h-4 text-purple-400" />
            <h2 className="text-sm font-bold text-slate-200">Sector Pulse Preview</h2>
          </div>
          <button
            onClick={() => onNavigate('sectors')}
            className="text-xs text-amber-400 hover:text-amber-300 flex items-center gap-1 font-medium"
          >
            Explore 8 Sectors <ArrowRight className="w-3 h-3" />
          </button>
        </div>

        <div className="grid grid-cols-2 gap-2">
          {data.sectors.slice(0, 4).map((sec) => (
            <div
              key={sec.id}
              onClick={() => onNavigate('sectors')}
              className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 cursor-pointer hover:border-slate-700"
            >
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-200 truncate">{sec.name}</span>
                <span
                  className={`text-[10px] font-bold px-1.5 py-0.2 rounded ${
                    sec.status === 'Bullish'
                      ? 'bg-emerald-500/15 text-emerald-400'
                      : sec.status === 'Bearish'
                      ? 'bg-rose-500/15 text-rose-400'
                      : 'bg-slate-700/30 text-slate-400'
                  }`}
                >
                  {sec.status}
                </span>
              </div>
              <div className="flex items-center justify-between mt-2 text-xs">
                <span className="text-slate-400">Score: {sec.score}/100</span>
                <span
                  className={`font-semibold ${
                    sec.avgMomentum >= 0 ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {sec.avgMomentum >= 0 ? '+' : ''}
                  {sec.avgMomentum}%
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
