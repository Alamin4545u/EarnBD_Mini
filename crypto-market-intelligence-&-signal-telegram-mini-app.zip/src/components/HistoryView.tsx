import { useState } from 'react';
import { History, TrendingUp, TrendingDown, CheckCircle2, XCircle, AlertCircle } from 'lucide-react';
import { BacktestRecord } from '../types/crypto.ts';
import { DisclaimerBanner } from './DisclaimerBanner.tsx';

interface HistoryViewProps {
  records: BacktestRecord[];
}

export function HistoryView({ records }: HistoryViewProps) {
  const [filterDirection, setFilterDirection] = useState<'ALL' | 'BULLISH' | 'BEARISH'>('ALL');

  const filtered = records.filter((r) => {
    if (filterDirection !== 'ALL' && r.direction !== filterDirection) return false;
    return true;
  });

  const favorableCount = records.filter((r) => r.outcome === 'FAVORABLE').length;
  const winRate = records.length > 0 ? Math.round((favorableCount / records.length) * 100) : 0;

  return (
    <div className="space-y-4 pb-20 pt-2">
      {/* Strict Disclaimer */}
      <DisclaimerBanner />

      {/* Header Stat summary */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-blue-950/30 via-slate-900 to-slate-900 border border-blue-500/20">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <History className="w-5 h-5 text-blue-400" />
              <h2 className="text-base font-bold text-slate-100">Backtesting & Audit Log</h2>
            </div>
            <p className="text-xs text-slate-300 mt-1">
              Multi-factor historical tracking at 1H, 6H, 12H, and 24H intervals.
            </p>
          </div>

          <div className="text-right">
            <div className="text-xl font-black text-emerald-400">{winRate}%</div>
            <div className="text-[10px] text-slate-400 font-medium">Model Confluence</div>
          </div>
        </div>

        {/* Filter buttons */}
        <div className="flex items-center gap-2 mt-3 pt-3 border-t border-slate-800">
          {(['ALL', 'BULLISH', 'BEARISH'] as const).map((dir) => (
            <button
              key={dir}
              onClick={() => setFilterDirection(dir)}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
                filterDirection === dir
                  ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                  : 'bg-slate-950/50 text-slate-400 hover:text-slate-200'
              }`}
            >
              {dir === 'ALL' ? 'All Setups' : dir === 'BULLISH' ? 'Bullish Only' : 'Bearish Only'}
            </button>
          ))}
        </div>
      </div>

      {/* Records list */}
      <div className="space-y-3">
        {filtered.map((item) => {
          const isBullish = item.direction === 'BULLISH';
          const dateStr = new Date(item.signalTime).toLocaleDateString('en-US', {
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
          });

          return (
            <div
              key={item.id}
              className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3 shadow-sm"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold ${
                      isBullish
                        ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                        : 'bg-rose-500/15 text-rose-400 border border-rose-500/30'
                    }`}
                  >
                    {isBullish ? <TrendingUp className="w-5 h-5" /> : <TrendingDown className="w-5 h-5" />}
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <h3 className="text-sm font-bold text-slate-100">{item.symbol}</h3>
                      <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-slate-800 text-slate-300">
                        {item.timeframe}
                      </span>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.2 rounded-full ${
                          item.outcome === 'FAVORABLE'
                            ? 'bg-emerald-500/15 text-emerald-400'
                            : 'bg-rose-500/15 text-rose-400'
                        }`}
                      >
                        {item.outcome}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-400 mt-0.5">
                      {dateStr} • Entry: ${item.entryPrice < 1 ? item.entryPrice.toFixed(4) : item.entryPrice.toLocaleString()}
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-base font-black text-amber-400">
                    {item.score}<span className="text-[10px] text-slate-400 font-normal">/100</span>
                  </div>
                  <div className="text-[10px] text-slate-400">Score at scan</div>
                </div>
              </div>

              {/* Price Excursion Tracking Intervals Grid */}
              <div className="grid grid-cols-4 gap-1.5 p-2 rounded-xl bg-slate-950/60 border border-slate-800/60 text-center text-xs">
                <div>
                  <div className="text-[10px] text-slate-400 font-medium">+1H</div>
                  <div className={`font-bold mt-0.5 ${item.change1hPct >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {item.change1hPct >= 0 ? '+' : ''}{item.change1hPct}%
                  </div>
                </div>

                <div>
                  <div className="text-[10px] text-slate-400 font-medium">+6H</div>
                  <div className={`font-bold mt-0.5 ${item.change6hPct >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {item.change6hPct >= 0 ? '+' : ''}{item.change6hPct}%
                  </div>
                </div>

                <div>
                  <div className="text-[10px] text-slate-400 font-medium">+12H</div>
                  <div className={`font-bold mt-0.5 ${item.change12hPct >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {item.change12hPct >= 0 ? '+' : ''}{item.change12hPct}%
                  </div>
                </div>

                <div>
                  <div className="text-[10px] text-slate-400 font-medium">+24H</div>
                  <div className={`font-bold mt-0.5 ${item.change24hPct >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {item.change24hPct >= 0 ? '+' : ''}{item.change24hPct}%
                  </div>
                </div>
              </div>

              {/* Notes */}
              <p className="text-[11px] text-slate-400 italic leading-snug">
                "{item.notes}"
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
}
