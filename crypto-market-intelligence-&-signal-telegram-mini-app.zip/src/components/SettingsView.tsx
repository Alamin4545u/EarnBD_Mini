import { useState } from 'react';
import {
  Bell,
  Sliders,
  Terminal,
  Send,
  CheckCircle2,
  Shield,
  Bot,
  RefreshCw,
} from 'lucide-react';
import { UserSettings } from '../types/crypto.ts';
import { triggerHaptic } from '../lib/telegram.ts';

interface SettingsViewProps {
  settings: UserSettings;
  onUpdateSettings: (updates: Partial<UserSettings>) => void;
  onExecuteCommand: (cmd: string) => Promise<any>;
}

export function SettingsView({
  settings,
  onUpdateSettings,
  onExecuteCommand,
}: SettingsViewProps) {
  const [activeCmd, setActiveCmd] = useState<string>('/start');
  const [cmdOutput, setCmdOutput] = useState<string | null>(null);
  const [cmdRunning, setCmdRunning] = useState<boolean>(false);
  const [testSentMsg, setTestSentMsg] = useState<string | null>(null);

  const handleToggle = (key: keyof UserSettings) => {
    triggerHaptic('light');
    onUpdateSettings({ [key]: !settings[key] });
  };

  const handleMinScoreChange = (score: 60 | 70 | 80 | 90) => {
    triggerHaptic('medium');
    onUpdateSettings({ minScore: score });
  };

  const runBotCommand = async (cmd: string) => {
    setActiveCmd(cmd);
    setCmdRunning(true);
    triggerHaptic('light');
    try {
      const res = await onExecuteCommand(cmd);
      if (res && res.text) {
        setCmdOutput(res.text);
      }
    } catch (err: any) {
      setCmdOutput(`Error: ${err.message}`);
    } finally {
      setCmdRunning(false);
    }
  };

  return (
    <div className="space-y-4 pb-20 pt-2">
      {/* Alert Thresholds Card */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
        <div className="flex items-center gap-2">
          <Sliders className="w-5 h-5 text-amber-400" />
          <h2 className="text-base font-bold text-slate-100">Notification Thresholds</h2>
        </div>

        {/* Minimum Score Tier */}
        <div>
          <label className="text-xs font-semibold text-slate-300 block mb-2">
            Minimum Signal Score Threshold
          </label>
          <div className="grid grid-cols-4 gap-2">
            {([60, 70, 80, 90] as const).map((score) => (
              <button
                key={score}
                id={`btn-minscore-${score}`}
                onClick={() => handleMinScoreChange(score)}
                className={`py-2 rounded-xl text-xs font-bold transition-all ${
                  settings.minScore === score
                    ? 'bg-amber-500 text-slate-950 shadow-sm shadow-amber-500/20'
                    : 'bg-slate-950/60 text-slate-400 border border-slate-800 hover:border-slate-700'
                }`}
              >
                {score}+
              </button>
            ))}
          </div>
          <p className="text-[11px] text-slate-400 mt-1.5">
            {settings.minScore >= 80
              ? 'Only high-probability strong setups will trigger alerts.'
              : 'Includes both moderate and high-conviction setups.'}
          </p>
        </div>

        {/* Toggles */}
        <div className="space-y-2.5 pt-2 border-t border-slate-800">
          <div className="flex items-center justify-between py-1">
            <div>
              <div className="text-xs font-bold text-slate-200">Bullish Setup Alerts</div>
              <div className="text-[11px] text-slate-400">Receive alerts when upside momentum builds</div>
            </div>
            <button
              onClick={() => handleToggle('bullishAlerts')}
              className={`w-11 h-6 rounded-full transition-colors relative ${
                settings.bullishAlerts ? 'bg-emerald-500' : 'bg-slate-800'
              }`}
            >
              <div
                className={`w-4 h-4 rounded-full bg-white transition-transform ${
                  settings.bullishAlerts ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          <div className="flex items-center justify-between py-1">
            <div>
              <div className="text-xs font-bold text-slate-200">Bearish Setup Alerts</div>
              <div className="text-[11px] text-slate-400">Receive alerts when downside risk expands</div>
            </div>
            <button
              onClick={() => handleToggle('bearishAlerts')}
              className={`w-11 h-6 rounded-full transition-colors relative ${
                settings.bearishAlerts ? 'bg-rose-500' : 'bg-slate-800'
              }`}
            >
              <div
                className={`w-4 h-4 rounded-full bg-white transition-transform ${
                  settings.bearishAlerts ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          <div className="flex items-center justify-between py-1">
            <div>
              <div className="text-xs font-bold text-slate-200">High-Score Priority Alerts</div>
              <div className="text-[11px] text-slate-400">Bypass cooldown for score 85+ setups</div>
            </div>
            <button
              onClick={() => handleToggle('highScoreAlerts')}
              className={`w-11 h-6 rounded-full transition-colors relative ${
                settings.highScoreAlerts ? 'bg-amber-500' : 'bg-slate-800'
              }`}
            >
              <div
                className={`w-4 h-4 rounded-full bg-white transition-transform ${
                  settings.highScoreAlerts ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          <div className="flex items-center justify-between py-1">
            <div>
              <div className="text-xs font-bold text-slate-200">Sector Shift Alerts</div>
              <div className="text-[11px] text-slate-400">Notify when sector sentiment flips</div>
            </div>
            <button
              onClick={() => handleToggle('sectorAlerts')}
              className={`w-11 h-6 rounded-full transition-colors relative ${
                settings.sectorAlerts ? 'bg-purple-500' : 'bg-slate-800'
              }`}
            >
              <div
                className={`w-4 h-4 rounded-full bg-white transition-transform ${
                  settings.sectorAlerts ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>
        </div>
      </div>

      {/* Interactive Telegram Bot Command Simulator */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bot className="w-5 h-5 text-sky-400" />
            <h3 className="text-base font-bold text-slate-100">Telegram Bot Console Simulator</h3>
          </div>
          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-sky-500/15 text-sky-300 border border-sky-500/30">
            Interactive Test
          </span>
        </div>

        <p className="text-xs text-slate-400">
          Execute any Telegram Bot command directly to inspect the exact bot reply and inline buttons.
        </p>

        {/* Command buttons pills */}
        <div className="flex flex-wrap gap-1.5">
          {[
            '/start',
            '/dashboard',
            '/signals',
            '/bullish',
            '/bearish',
            '/sectors',
            '/market',
            '/watchlist',
            '/history',
            '/settings',
          ].map((cmd) => (
            <button
              key={cmd}
              onClick={() => runBotCommand(cmd)}
              className={`px-2.5 py-1 rounded-lg text-xs font-mono font-medium transition-all ${
                activeCmd === cmd
                  ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40 font-bold'
                  : 'bg-slate-950/70 text-slate-300 border border-slate-800 hover:border-slate-700'
              }`}
            >
              {cmd}
            </button>
          ))}
        </div>

        {/* Output Screen */}
        <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 text-xs font-mono text-slate-300 space-y-2">
          <div className="flex items-center justify-between text-[11px] text-slate-500 pb-1 border-b border-slate-800">
            <span>Terminal: {activeCmd}</span>
            {cmdRunning && <RefreshCw className="w-3 h-3 animate-spin text-sky-400" />}
          </div>
          <div
            className="whitespace-pre-wrap leading-relaxed max-h-48 overflow-y-auto text-slate-200"
            dangerouslySetInnerHTML={{
              __html:
                cmdOutput ||
                'Tap any command above to simulate live Telegram Bot response...',
            }}
          />
        </div>
      </div>
    </div>
  );
}
